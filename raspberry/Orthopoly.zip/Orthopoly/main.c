#include<stdio.h>
#include<assert.h>
#include<stdlib.h>
#include<math.h>
#include<sys/time.h>

/* LegenVal evaluates a series of legendre polynomial at the point x, which is in [-1, 1].*/


double LegenVal(double *P, unsigned int n, double x)
{
    assert ( 0 < n);
    assert (fabs(x)<=1.0);
    double  t,b1=0,b2=0;
    int j;
    double i;

    for(j=n; j>=1; j--) 
    {
        i=1.0*j;
        t=(2*i+1)/(i+1)*x*b1-(i+1)/(i+2)*b2+P[j];
        b2=b1;
        b1=t;
    }
    return x*b1-b2/2+P[0];
}

/*LegenDer evaluates  the first derivative of a series of legendre polynomial at the point x, which is in [-1, 1]. */
double LegenDer(double *P, unsigned int n, double x)
{
    assert ( 0 < n);
    assert (fabs(x)<=1.0);
    double  t,b1=0,b2=0;
    int j;
    double i;

    for(j=n-1; j>=0; j--) 
    {
        i=1.0*j;
        t=(2*i+3)/(i+1)*x*b1-(i+3)/(i+2)*b2+P[j+1];
        b2=b1;
        b1=t;
    }
    return  b1;
}

/*LegenDerK evaluates  the k-th derivative of a series of legendre polynomial at the point x, which is in [-1, 1]. */
double LegenDerK(double *P, unsigned int n, double x, unsigned int k)
{
    assert ( 0 < n);
    assert (fabs(x)<=1.0);
    double  s=1.0,t,b1=0,b2=0;
    int j;
    double i;

    for(j=2*k-1;j>0;j=j-2)
    {
        s=j*s;
    }
    double  A1,A2;

    for(j=n-k; j>=0; j--) 
    {
        i=1.0*j;
        A1=(2*i+2*k+1)/(i+1)*x;
        A2=-(i+2*k+1)/(i+2);
        t=A1*b1+A2*b2+P[j+k];

        b2=b1;
        b1=t;
    }
    return  s*b1;
}

void legen(){
	struct timeval st, et;
	int elapsed;
 	//Val
	double res_val;
	gettimeofday(&st,NULL);
	double x_val=0.65;
 	int n_val=17;
 	double p_val[]={-2699.915949654920243155538,7294.954964701191481377250,-9855.340953819572240624893,10051.56898107052905814518,-8442.942168319296802268938,6027.152042271538081875930,-3704.426571905112506135507,1968.958712915444137681290,-904.3828105802791157482192,357.3311403326828518644365,-120.4460531417831357257847,34.20556390836229632004353,-8.038700860731022120912915,1.523326182709104850355380,-0.2238790056018962788199805,0.02396245039753007133932317,-0.001662712703037941393453644,0.00005616714545781420772147874};
	res_val=LegenVal(p_val,n_val,x_val);
	gettimeofday(&et,NULL);
	elapsed = ((et.tv_sec - st.tv_sec) * 1000000) + (et.tv_usec - st.tv_usec);
	printf("LegenVal time: %d micro seconds\n",elapsed);	
 	printf("the result of LegenVal is %14.14e\n",res_val);
 	//Der
	double res_der;
	gettimeofday(&st,NULL);
	double x_der=0.65;
 	int n_der=17;
 	double p_der[]={-2699.915949654920243155538,7294.954964701191481377250,-9855.340953819572240624893,10051.56898107052905814518,-8442.942168319296802268938,6027.152042271538081875930,-3704.426571905112506135507,1968.958712915444137681290,-904.3828105802791157482192,357.3311403326828518644365,-120.4460531417831357257847,34.20556390836229632004353,-8.038700860731022120912915,1.523326182709104850355380,-0.2238790056018962788199805,0.02396245039753007133932317,-0.001662712703037941393453644,0.00005616714545781420772147874};
	res_der=LegenDer(p_der,n_der,x_der);
	gettimeofday(&et,NULL);
	elapsed = ((et.tv_sec - st.tv_sec) * 1000000) + (et.tv_usec - st.tv_usec);
	printf("LegenDer time: %d micro seconds\n",elapsed);	
 	printf("the result of LegenDer is %14.14e\n",res_der);
 	//DerK
 	double res_derK;
	gettimeofday(&st,NULL);
	double x_derK=0.65;
 	int n_derK=17;
 	int k=4;
 	double p_derK[]={-2699.915949654920243155538,7294.954964701191481377250,-9855.340953819572240624893,10051.56898107052905814518,-8442.942168319296802268938,6027.152042271538081875930,-3704.426571905112506135507,1968.958712915444137681290,-904.3828105802791157482192,357.3311403326828518644365,-120.4460531417831357257847,34.20556390836229632004353,-8.038700860731022120912915,1.523326182709104850355380,-0.2238790056018962788199805,0.02396245039753007133932317,-0.001662712703037941393453644,0.00005616714545781420772147874};
	res_derK=LegenDerK(p_val,n_derK,x_val,k);
	gettimeofday(&et,NULL);
	elapsed = ((et.tv_sec - st.tv_sec) * 1000000) + (et.tv_usec - st.tv_usec);
	printf("LegenDerk time: %d micro seconds\n",elapsed);	
 	printf("the result of LegenDerK is %14.14e\n",res_derK);
}

/* Herm1Val evaluates a series of Hermite polynomial He at the point x.*/
double Herm1Val(double *P, unsigned int n, double x)
{
    assert ( 0 < n);
    double  t,b1=0,b2=0;
    int i;

    for(i=n; i>=0; i--) 
    {
        t=x*b1-(i+1)*b2+P[i];
        b2=b1;
        b1=t;
    }
    return b1;
}

/*Herm1Der evaluates the first derivative of a series of Hermite polynomial He at the point x. */
double Herm1Der(double *P, unsigned int n, double x)
{
    assert ( 0 < n);
    double  t,b1=0,b2=0;
    int i;

    for(i=n-1; i>=0; i--) 
    {
        t=x*b1-(i+1)*b2+(i+1)*P[i+1];
        b2=b1;
        b1=t;
    }
    return b1;
}

/*Herm1DerK evaluates  the k-th derivative of a series of Hermite polynomial He at the point x. */
double Herm1DerK(double *P, unsigned int n, double x, unsigned int k)
{
    assert ( 0 < n);
    double  t,s,b1=0,b2=0;
    int i,j;

    for(i=n-k; i>=0; i--) 
    {
        s=1.0;
        for(j=i+k;j>=i+1;j--)
        {
            s=s*j;
        }
        t=x*b1-(i+1)*b2+s*P[i+k];
        b2=b1;
        b1=t;
    }
    return b1;
}

void herm1(){
	struct timeval st, et;
	int elapsed;
 	//Val
	double res_val;
	gettimeofday(&st,NULL);
	double x_val=0.65;
 	int n_val=17;
 	double p_val[]={-28471492267.0/4194304.0,26980769367.0/2097152.0,-45904273683.0/4194304.0,17507317561.0/2097152.0,-11950694063.0/2097152.0,14559064751.0/4194304.0,-15766137527.0/8388608.0,3774819027.0/4194304.0,-1588096377.0/4194304.0,582044911.0/4194304.0,-367619987.0/8388608.0,49300931.0/4194304.0,-5507631.0/2097152.0,498871.0/1048576.0,-35209.0/524288.0,1817.0/262144.0,-61.0/131072.0,1.0/65536.0};
	res_val=Herm1Val(p_val,n_val,x_val);
	gettimeofday(&et,NULL);
	elapsed = ((et.tv_sec - st.tv_sec) * 1000000) + (et.tv_usec - st.tv_usec);
	printf("Herm1Val time: %d micro seconds\n",elapsed);	
 	printf("the result of Herm1Val is %14.14e\n",res_val);
 	//Der
	double res_der;
	gettimeofday(&st,NULL);
	double x_der=0.65;
 	int n_der=17;
 	double p_der[]={-28471492267.0/4194304.0,26980769367.0/2097152.0,-45904273683.0/4194304.0,17507317561.0/2097152.0,-11950694063.0/2097152.0,14559064751.0/4194304.0,-15766137527.0/8388608.0,3774819027.0/4194304.0,-1588096377.0/4194304.0,582044911.0/4194304.0,-367619987.0/8388608.0,49300931.0/4194304.0,-5507631.0/2097152.0,498871.0/1048576.0,-35209.0/524288.0,1817.0/262144.0,-61.0/131072.0,1.0/65536.0};
	res_der=Herm1Der(p_der,n_der,x_der);
	gettimeofday(&et,NULL);
	elapsed = ((et.tv_sec - st.tv_sec) * 1000000) + (et.tv_usec - st.tv_usec);
	printf("Herm1Der time: %d micro seconds\n",elapsed);	
 	printf("the result of Herm1Der is %14.14e\n",res_der);
 	//DerK
 	double res_derK;
	gettimeofday(&st,NULL);
	double x_derK=0.65;
 	int n_derK=17;
 	int k=4;
 	double p_derK[]={-28471492267.0/4194304.0,26980769367.0/2097152.0,-45904273683.0/4194304.0,17507317561.0/2097152.0,-11950694063.0/2097152.0,14559064751.0/4194304.0,-15766137527.0/8388608.0,3774819027.0/4194304.0,-1588096377.0/4194304.0,582044911.0/4194304.0,-367619987.0/8388608.0,49300931.0/4194304.0,-5507631.0/2097152.0,498871.0/1048576.0,-35209.0/524288.0,1817.0/262144.0,-61.0/131072.0,1.0/65536.0};
	res_derK=Herm1DerK(p_val,n_derK,x_val,k);
	gettimeofday(&et,NULL);
	elapsed = ((et.tv_sec - st.tv_sec) * 1000000) + (et.tv_usec - st.tv_usec);
	printf("Herm1Derk time: %d micro seconds\n",elapsed);	
 	printf("the result of Herm1DerK is %14.14e\n",res_derK);
 	
 	
}

/*Herm2Val evaluates a series of Hermite polynomial H at the point x. */
double Herm2Val(double *P, unsigned int n, double x)
{
    assert ( 0 < n);
    double  xx,t,b1=0,b2=0;
    int i;
    xx=2*x;

    for(i=n; i>=0; i--) 
    {
        t=xx*b1-2*(i+1)*b2+P[i];
        b2=b1;
        b1=t;
    }
    return b1;
}

/*Herm2Der evaluates  the first  derivative of a series of Hermite polynomial H at the point x. */
double Herm2Der(double *P, unsigned int n, double x)
{
    assert ( 0 < n);
    double  xx,t,b1=0,b2=0;
    int i;
    xx=2*x;

    for(i=n-1; i>=0; i--) 
    {
        t=xx*b1-2*(i+1)*b2+2*(i+1)*P[i+1];
        b2=b1;
        b1=t;
    }
    return  b1;
}

/*Herm2DerK evaluates  the k-th  derivative of a series of Hermite polynomial H at the point x. */
double Herm2DerK(double *P, unsigned int n, double x, unsigned int k)
{
    assert ( 0 < n);
    double  xx,C=1.0,s,t,b1=0,b2=0;
    int i,j;
    for(i=k;i>0;i--)
        {
            C=2*C;
        }
        xx=2*x;

    for(i=n-k; i>=0; i--) 
    {
        s=1.0;
        for(j=i+k;j>=i+1;j--)
        {
            s=s*j;
        }
        t=xx*b1-2*(i+1)*b2+s*P[i+k];

        b2=b1;
        b1=t;
    }
return  C*b1;
}

void herm2(){
	struct timeval st, et;
	int elapsed;
 	//Val
	double res_val;
	gettimeofday(&st,NULL);
	double x_val=0.65;
 	int n_val=17;
 	double p_val[]={-28471492267.0/4194304.0,26980769367.0/2097152.0,-45904273683.0/4194304.0,17507317561.0/2097152.0,-11950694063.0/2097152.0,14559064751.0/4194304.0,-15766137527.0/8388608.0,3774819027.0/4194304.0,-1588096377.0/4194304.0,582044911.0/4194304.0,-367619987.0/8388608.0,49300931.0/4194304.0,-5507631.0/2097152.0,498871.0/1048576.0,-35209.0/524288.0,1817.0/262144.0,-61.0/131072.0,1.0/65536.0};
	res_val=Herm2Val(p_val,n_val,x_val);
	gettimeofday(&et,NULL);
	elapsed = ((et.tv_sec - st.tv_sec) * 1000000) + (et.tv_usec - st.tv_usec);
	printf("Herm2Val time: %d micro seconds\n",elapsed);	
 	printf("the result of Herm2Val is %14.14e\n",res_val);
 	//Der
	double res_der;
	gettimeofday(&st,NULL);
	double x_der=0.65;
 	int n_der=17;
 	double p_der[]={-28471492267.0/4194304.0,26980769367.0/2097152.0,-45904273683.0/4194304.0,17507317561.0/2097152.0,-11950694063.0/2097152.0,14559064751.0/4194304.0,-15766137527.0/8388608.0,3774819027.0/4194304.0,-1588096377.0/4194304.0,582044911.0/4194304.0,-367619987.0/8388608.0,49300931.0/4194304.0,-5507631.0/2097152.0,498871.0/1048576.0,-35209.0/524288.0,1817.0/262144.0,-61.0/131072.0,1.0/65536.0};
	res_der=Herm2Der(p_der,n_der,x_der);
	gettimeofday(&et,NULL);
	elapsed = ((et.tv_sec - st.tv_sec) * 1000000) + (et.tv_usec - st.tv_usec);
	printf("Herm2Der time: %d micro seconds\n",elapsed);	
 	printf("the result of Herm2Der is %14.14e\n",res_der);
 	//DerK
 	double res_derK;
	gettimeofday(&st,NULL);
	double x_derK=0.65;
 	int n_derK=17;
 	int k=4;
 	double p_derK[]={-28471492267.0/4194304.0,26980769367.0/2097152.0,-45904273683.0/4194304.0,17507317561.0/2097152.0,-11950694063.0/2097152.0,14559064751.0/4194304.0,-15766137527.0/8388608.0,3774819027.0/4194304.0,-1588096377.0/4194304.0,582044911.0/4194304.0,-367619987.0/8388608.0,49300931.0/4194304.0,-5507631.0/2097152.0,498871.0/1048576.0,-35209.0/524288.0,1817.0/262144.0,-61.0/131072.0,1.0/65536.0};
	res_derK=Herm2DerK(p_val,n_derK,x_val,k);
	gettimeofday(&et,NULL);
	elapsed = ((et.tv_sec - st.tv_sec) * 1000000) + (et.tv_usec - st.tv_usec);
	printf("Herm2Derk time: %d micro seconds\n",elapsed);	
 	printf("the result of Herm2DerK is %14.14e\n",res_derK);
 	
 	
}

/* Cheb1Val evaluates a series of Chebyshev polynomial of the first kind at the point x, which is in [-1, 1].*/
double Cheb1Val(double *P, unsigned int n, double x)
{
    assert ( 0 < n);
    assert (fabs(x)<=1.0);
    double  xx,t,b1=0,b2=0;
    int i;
    xx=2*x;

    for(i=n; i>=1; i--) 
    {
        t=xx*b1-b2+P[i];
        b2=b1;
        b1=t;
    }
    return x*b1-b2+P[0];
}
/*Cheb1Der evaluates  the first derivative of a series of Chebyshev polynomial of the first kind at the point x, which is in [-1, 1]. */
double Cheb1Der(double *P, unsigned int n, double x)
{
    assert ( 0 < n);
    assert (fabs(x)<=1.0);
    double  xx,t,b1=0,b2=0;
    int i;
    xx=2*x;

    for(i=n; i>=1; i--) 
    {
        t=xx*b1-b2+(i)*P[i];
        b2=b1;
        b1=t;
    }
    return  b1;
}
/*Cheb1DerK evaluates  the k-th derivative of a series of Chebyshev polynomial of the first kind at the point x, which is in [-1, 1]. */
double Cheb1DerK(double *P, unsigned int n, double x, unsigned int k)
{
    assert ( 0 < n);
    assert (fabs(x)<=1.0);
    double  s=1.0,t,b1=0,b2=0;
    int i;
    double j;
    if(k==0){
    j=Cheb1Val(P,n,x);
    return j;
    }

    for(i=k-1;i>0;i--)
    {
       s=2*s*i;
    }
    
    for(i=n-k; i>=0; i--) 
    {
        j=1.0*i;
        t=2*(j+k)/(j+1)*x*b1-(j+2*k)/(j+2)*b2+(j+k)*P[i+k];
        b2=b1;
        b1=t;
    }
    return  s*b1;
}

void cheb1(){
	struct timeval st, et;
	int elapsed;
 	//Val
	double res_val;
	gettimeofday(&st,NULL);
	double x_val=0.65;
 	int n_val=17;
 	double p_val[]={-28471492267.0/4194304.0,26980769367.0/2097152.0,-45904273683.0/4194304.0,17507317561.0/2097152.0,-11950694063.0/2097152.0,14559064751.0/4194304.0,-15766137527.0/8388608.0,3774819027.0/4194304.0,-1588096377.0/4194304.0,582044911.0/4194304.0,-367619987.0/8388608.0,49300931.0/4194304.0,-5507631.0/2097152.0,498871.0/1048576.0,-35209.0/524288.0,1817.0/262144.0,-61.0/131072.0,1.0/65536.0};
	res_val=Cheb1Val(p_val,n_val,x_val);
	gettimeofday(&et,NULL);
	elapsed = ((et.tv_sec - st.tv_sec) * 1000000) + (et.tv_usec - st.tv_usec);
	printf("Cheb1Val time: %d micro seconds\n",elapsed);	
 	printf("the result of Cheb1Val is %14.14e\n",res_val);
 	//Der
	double res_der;
	gettimeofday(&st,NULL);
	double x_der=0.65;
 	int n_der=17;
 	double p_der[]={-28471492267.0/4194304.0,26980769367.0/2097152.0,-45904273683.0/4194304.0,17507317561.0/2097152.0,-11950694063.0/2097152.0,14559064751.0/4194304.0,-15766137527.0/8388608.0,3774819027.0/4194304.0,-1588096377.0/4194304.0,582044911.0/4194304.0,-367619987.0/8388608.0,49300931.0/4194304.0,-5507631.0/2097152.0,498871.0/1048576.0,-35209.0/524288.0,1817.0/262144.0,-61.0/131072.0,1.0/65536.0};
	res_der=Cheb1Der(p_der,n_der,x_der);
	gettimeofday(&et,NULL);
	elapsed = ((et.tv_sec - st.tv_sec) * 1000000) + (et.tv_usec - st.tv_usec);
	printf("Cheb1Der time: %d micro seconds\n",elapsed);	
 	printf("the result of Cheb1Der is %14.14e\n",res_der);
 	//DerK
 	double res_derK;
	gettimeofday(&st,NULL);
	double x_derK=0.65;
 	int n_derK=17;
 	int k=4;
 	double p_derK[]={-28471492267.0/4194304.0,26980769367.0/2097152.0,-45904273683.0/4194304.0,17507317561.0/2097152.0,-11950694063.0/2097152.0,14559064751.0/4194304.0,-15766137527.0/8388608.0,3774819027.0/4194304.0,-1588096377.0/4194304.0,582044911.0/4194304.0,-367619987.0/8388608.0,49300931.0/4194304.0,-5507631.0/2097152.0,498871.0/1048576.0,-35209.0/524288.0,1817.0/262144.0,-61.0/131072.0,1.0/65536.0};
	res_derK=Cheb1DerK(p_val,n_derK,x_val,k);
	gettimeofday(&et,NULL);
	elapsed = ((et.tv_sec - st.tv_sec) * 1000000) + (et.tv_usec - st.tv_usec);
	printf("Cheb1DerK time: %d micro seconds\n",elapsed);	
 	printf("the result of Cheb1DerK is %14.14e\n",res_derK);
}

/*Cheb2Val evaluates a series of Chebyshev polynomial of the second kind at the point x, which is in [-1, 1]. */
double Cheb2Val(double *P, unsigned int n, double x)
{
    assert ( 0 < n);
    assert (fabs(x)<=1.0);
    double  xx,t,b1=0,b2=0;
    int i;
    xx=2*x;

    for(i=n; i>=1; i--) 
    {
        t=xx*b1-b2+P[i];
        b2=b1;
        b1=t;
    }
    return 2*x*b1-b2+P[0];
}
/*Cheb2Der evaluates  the first  derivative of a series of Chebyshev polynomial of the second kind at the point x, which is in [-1, 1]. */
double Cheb2Der(double *P, unsigned int n, double x)
{
    assert ( 0 < n);
    assert (fabs(x)<=1.0);
    double  t,b1=0,b2=0;
    double  A1,A2;
    int i;
    double C;
    C=2;

    for(i=n-1; i>=0; i--) 
    {
        A1=(2*i+4)*x/(i+1);
        A2=-1.0*(i+4)/(i+2);
        t=A1*b1+A2*b2+P[i+1];
        b2=b1;
        b1=t;
    }
    return  C*b1;
}

/*Cheb2DerK evaluates  the k-th  derivative of a series of Chebyshev polynomial of the second kind at the point x, which is in [-1, 1]. */
double Cheb2DerK(double *P, unsigned int n, double x, unsigned int k)
{
    assert ( 0 < n);
    assert (fabs(x)<=1.0);
    double  t,b1=0,b2=0;
    int i;
    double s=1.0,j;
    for(i=k;i>0;i--)
    {
       s=2*s*i;
    }

    for(i=n-k; i>=0; i--) 
    {
        j=1.0*i;
        t=2*(j+k+1)/(j+1)*x*b1-(j+2*k+2)/(j+2)*b2+P[i+k];
        b2=b1;
        b1=t;
    }
    return  s*b1;
}


void cheb2(){
	struct timeval st, et;
	int elapsed;
 	//Val
	double res_val;
	gettimeofday(&st,NULL);
	double x_val=0.65;
 	int n_val=17;
 	double p_val[]={-1315.91687810420989990234375,2258.646918773651123046875,-2622.94835531711578369140625,2438.49401128292083740234375,-1909.532471001148223876953125,1285.582271099090576171875,-750.419185936450958251953125,380.608334064483642578125,-167.403982102870941162109375,63.508031368255615234375,-20.598737180233001708984375,5.63924872875213623046875,-1.2795436382293701171875,0.234414577484130859375,-0.03334522247314453125,0.0034580230712890625,-0.000232696533203125,0.00000762939453125};
	res_val=Cheb2Val(p_val,n_val,x_val);
	gettimeofday(&et,NULL);
	elapsed = ((et.tv_sec - st.tv_sec) * 1000000) + (et.tv_usec - st.tv_usec);
	printf("Cheb2Val time: %d micro seconds\n",elapsed);	
 	printf("the result of Cheb2Val is %14.14e\n",res_val);
 	//Der
	double res_der;
	gettimeofday(&st,NULL);
	double x_der=0.65;
 	int n_der=17;
 	double p_der[]={-1315.91687810420989990234375,2258.646918773651123046875,-2622.94835531711578369140625,2438.49401128292083740234375,-1909.532471001148223876953125,1285.582271099090576171875,-750.419185936450958251953125,380.608334064483642578125,-167.403982102870941162109375,63.508031368255615234375,-20.598737180233001708984375,5.63924872875213623046875,-1.2795436382293701171875,0.234414577484130859375,-0.03334522247314453125,0.0034580230712890625,-0.000232696533203125,0.00000762939453125};
	res_der=Cheb2Der(p_der,n_der,x_der);
	gettimeofday(&et,NULL);
	elapsed = ((et.tv_sec - st.tv_sec) * 1000000) + (et.tv_usec - st.tv_usec);
	printf("Cheb2Der time: %d micro seconds\n",elapsed);	
 	printf("the result of Cheb2Der is %14.14e\n",res_der);
 	//DerK
 	double res_derK;
	gettimeofday(&st,NULL);
	double x_derK=0.65;
 	int n_derK=17;
 	int k=4;
 	double p_derK[]={-1315.91687810420989990234375,2258.646918773651123046875,-2622.94835531711578369140625,2438.49401128292083740234375,-1909.532471001148223876953125,1285.582271099090576171875,-750.419185936450958251953125,380.608334064483642578125,-167.403982102870941162109375,63.508031368255615234375,-20.598737180233001708984375,5.63924872875213623046875,-1.2795436382293701171875,0.234414577484130859375,-0.03334522247314453125,0.0034580230712890625,-0.000232696533203125,0.00000762939453125};
	res_derK=Cheb2DerK(p_val,n_derK,x_val,k);
	gettimeofday(&et,NULL);
	elapsed = ((et.tv_sec - st.tv_sec) * 1000000) + (et.tv_usec - st.tv_usec);
	printf("Cheb2DerK time: %d micro seconds\n",elapsed);	
 	printf("the result of Cheb2DerK is %14.14e\n",res_derK);
 	
 	
}


void RecurCoefGegen (double n, double lambda,  double *A, double *C)
{
    int i;
    double j;
    for (i=1;i<=n+2;i++)
    {
        j=1.0*i;
        A[i-1]=2*(j+lambda-1)/j;
        C[i-1]=(j+2*lambda-2)/j;
    }
}

/*GegenVal evaluates a series of Gegenbauer polynomial at the point x, which is in [-1, 1] */
double GegenVal(double *P, unsigned int n, double x, double lambda)
{
    assert ( 0 < n);
    assert (fabs(x)<=1.0);
    assert (lambda>-0.5);
    assert (lambda!=0);
    double  t,b1=0,b2=0;
    int j;

    double *A=(double *) malloc(sizeof(double)*(n+2));
    double *C=(double *) malloc(sizeof(double)*(n+2));

    RecurCoefGegen(n,lambda,A,C);

    for(j=n; j>=0; j--)
    {
        t=*(A+j)*x*b1-*(C+j+1)*b2+P[j];
        b2=b1;
        b1=t;
    }
    free(A);
    free(C);
    return b1;
}

/*GegenDer evaluates  the first derivative of a series of Gegenbauer polynomial at the point x, which is in [-1, 1] */
double GegenDer(double *P, unsigned int n, double x, double lambda)
{
    assert ( 0 < n);
    assert (fabs(x)<=1.0);
    assert (lambda>-0.5);
    assert (lambda!=0);
    double  t,b1=0,b2=0;
    double A1, A2;
    int i;
    double j;
    double C=2*lambda;

    for(i=n-1; i>=0; i--)
    {
        j=1.0*i;
//-------------recurrence coefficients-----------------------//
        A1=2*(j+1+lambda)*x/(j+1);
        A2=-(j+2*lambda+2)/(j+2);
//--------------iteration------------------------------------//
        t=A1*b1+A2*b2+P[i+1];
        b2=b1;
        b1=t;
    }
    return  C*b1;
}

/*GegenDerK evaluates  the k-th derivative of a series of Gegenbauer polynomial at the point x, which is in [-1, 1] */
double GegenDerK(double *P, unsigned int n, double x, double lambda, unsigned int k)
{
    assert ( 0 < n);
    assert (fabs(x)<=1.0);
    assert (lambda>-0.5);
    assert (lambda!=0);
    double  s=1.0,t,b1=0,b2=0;
    double A1, A2;
    int i;
    double j;
    for(i=1;i<=k;i++)
    {
        s=2*s*(lambda+i-1);
     }

    for(i=n-k; i>=0; i--)
    {
        j=1.0*i;
//-------------recurrence coefficients-----------------------//
       	A1=2*(j+k+lambda)*x/(j+1);
       	A2=-(j+2*lambda+2*k)/(j+2);
//--------------iteration-----------------------------------//
        t=A1*b1+A2*b2+P[i+k];

        b2=b1;
        b1=t;
    }
    return  s*b1;
}

void gegen(){
	struct timeval st, et;
	int elapsed;
 	//Val
	double res_val;
	gettimeofday(&st,NULL);
	double lambda_val=0.1;
	double x_val=0.65;
 	int n_val=17;
 	double p_val[]={-5519.293981327233066492480,56938.39132709945770922845,-91563.06755535588464893715,102138.3111747267800498606,-91390.68590697961077663426,68657.12752193417008543252,-44100.88354121754231424355,24386.84606480670093305547,-11616.31191831442987520578,4748.151213920654766176631,-1652.503681640035662508434,483.7838889893579801893316,-117.0476967480900562237535,22.80826826011093041346609,-3.443497607139100737840257,0.3782868329050993116058965,-0.02691969449476297499191505,0.0009319515454861432627790780};
	res_val=GegenVal(p_val,n_val,x_val,lambda_val);
	gettimeofday(&et,NULL);
	elapsed = ((et.tv_sec - st.tv_sec) * 1000000) + (et.tv_usec - st.tv_usec);
	printf("GegenVal time: %d micro seconds\n",elapsed);	
 	printf("the result of GegenVal is %14.14e\n",res_val);
 	//Der
	double res_der;
	gettimeofday(&st,NULL);
	double lambda_der=0.1;
	double x_der=0.65;
 	int n_der=17;
 	double p_der[]={-5519.293981327233066492480,56938.39132709945770922845,-91563.06755535588464893715,102138.3111747267800498606,-91390.68590697961077663426,68657.12752193417008543252,-44100.88354121754231424355,24386.84606480670093305547,-11616.31191831442987520578,4748.151213920654766176631,-1652.503681640035662508434,483.7838889893579801893316,-117.0476967480900562237535,22.80826826011093041346609,-3.443497607139100737840257,0.3782868329050993116058965,-0.02691969449476297499191505,0.0009319515454861432627790780};
	res_der=GegenDer(p_der,n_der,x_der,lambda_der);
	gettimeofday(&et,NULL);
	elapsed = ((et.tv_sec - st.tv_sec) * 1000000) + (et.tv_usec - st.tv_usec);
	printf("GegenDer time: %d micro seconds\n",elapsed);	
 	printf("the result of GegenDer is %14.14e\n",res_der);
 	//DerK
 	double res_derK;
	gettimeofday(&st,NULL);
	double lambda_derK=0.1;
	double x_derK=0.65;
 	int n_derK=17;
 	int k=4;
 	double p_derK[]={-5519.293981327233066492480,56938.39132709945770922845,-91563.06755535588464893715,102138.3111747267800498606,-91390.68590697961077663426,68657.12752193417008543252,-44100.88354121754231424355,24386.84606480670093305547,-11616.31191831442987520578,4748.151213920654766176631,-1652.503681640035662508434,483.7838889893579801893316,-117.0476967480900562237535,22.80826826011093041346609,-3.443497607139100737840257,0.3782868329050993116058965,-0.02691969449476297499191505,0.0009319515454861432627790780};
	res_derK=GegenDerK(p_val,n_derK,x_val,lambda_derK,k);
	gettimeofday(&et,NULL);
	elapsed = ((et.tv_sec - st.tv_sec) * 1000000) + (et.tv_usec - st.tv_usec);
	printf("GegenDerK time: %d micro seconds\n",elapsed);	
 	printf("the result of GegenDerK is %14.14e\n",res_derK);
}



//----------------------- The three-term recurrence coefficients of jacobi polynomial ----------------------------------
void RecurCoefJacob (double n, double alpha, double beta,  double *A, double *B, double *C)
{
    int i;
    double j;
    for (i=1;i<=n+2;i++)
    {
        j=1.0*i;
        A[i-1]=(2*j+alpha+beta-1)*(2*j+alpha+beta)/(2*j*(j+alpha+beta));
        B[i-1]=(alpha*alpha-beta*beta)*(2*j+alpha+beta-1)/(2*j*(j+alpha+beta)*(2*j+alpha+beta-2));
        C[i-1]=(j-1+alpha)*(j-1+beta)*(2*j+alpha+beta)/(j*(j+alpha+beta)*(2*j+alpha+beta-2));
    }
}

/* JacobVal evaluates a series of Jacobobi polynomial at the point x, which is in [-1, 1].*/
double JacobVal(double *P, unsigned int n, double x, double alpha, double beta)
{
    assert ( 0 < n);
    assert (fabs(x)<=1.0);
    assert (alpha>-1.0);
    assert (beta>-1.0);

    double  t,b1=0,b2=0;
    int j;

    double A[n+2];
    double B[n+2];
    double C[n+2];

    RecurCoefJacob(n,alpha,beta,A,B,C);

    for(j=n; j>=0; j--) 
    {
        t=(*(A+j)*x+*(B+j))*b1-*(C+j+1)*b2+P[j];

        b2=b1;
        b1=t;
    }

    return b1;
}

/*JacobDer evaluates  the first derivative of a series of Jacobobi polynomial at the point x, which is in [-1, 1]. */
double JacobDer(double *P, unsigned int n, double x, double alpha, double beta)
{
    assert ( 0 < n);
    assert (fabs(x)<=1.0);
    assert (alpha>-1.0);
    assert (beta>-1.0);
    double  t,b1=0,b2=0;
    double Ac, A1, A2;
    double a10,a11,a12,a20,a21;
    int i;
    double j;
    double C=0.5;

    for(i=n-1; i>=0; i--) 
    {
        j=1.0*i;
//-------------recurrence coefficients-----------------------//
        Ac=j+2+alpha+beta;
        a10=(2*j+3+alpha+beta)/((2*j+2)*(j+3+alpha+beta));
        a11=(2*j+4+alpha+beta)*x;
        a12=((alpha-beta)*(alpha+beta+2))/(alpha+beta+2*j+2);
        A1=a10*(a11+a12);
        a20=-(j+2+alpha)*(j+2+beta)/((j+2)*(alpha+beta+j+4));
        a21=(alpha+beta+2*j+6)/(alpha+beta+2*j+4);
        A2=a20*a21;
//--------------iteration-----------------------------------//
        t=A1*b1+A2*b2+Ac*P[i+1];

        b2=b1;
        b1=t;
    }
    return  C*b1;
}


/*JacobDerK evaluates the k-th derivative of a series of Jacobobi polynomial at the point x, which is in [-1, 1]. */
double JacobDerK(double *P, unsigned int n, double x, double alpha, double beta, unsigned int k)
{
    assert ( 0 < n);
    assert (fabs(x)<=1.0);
    assert (alpha>-1.0);
    assert (beta>-1.0);
    double  t,b1=0,b2=0;
    double A1, A2,s;
    double a10,a11,a12,a20,a21;
    int i,j;
    double C=1.0;
    for(i=k;i>0;i--)
    {
        C=C/2.0;
    }

    for(i=n-k; i>=0; i--) 
    {
//-------------recurrence coefficients-----------------------//
        s=1.0;
        for(j=1;j<=k;j++)
        {
            s=s*(alpha+beta+i+k+j);
        }
        a10=(2*i+1+2*k+alpha+beta)/((2*i+2)*(i+1+2*k+alpha+beta));
        a11=(2*i+2+2*k+alpha+beta)*x;
        a12=((alpha-beta)*(alpha+beta+2*k))/(alpha+beta+2*i+2*k);
        A1=a10*(a11+a12);
        
        a20=-(i+1+k+alpha)*(i+1+k+beta)/((i+2)*(alpha+beta+i+2+2*k));
        a21=(alpha+beta+2*i+4+2*k)/(alpha+beta+2*i+2+2*k);
        A2=a20*a21;
//--------------iteration-----------------------------------//
    t=A1*b1+A2*b2+s*P[i+k];

    b2=b1;
    b1=t;
    }
    return  C*b1;
}

void jacob(){
	struct timeval st, et;
	int elapsed;
 	//Val
	double res_val;
	gettimeofday(&st,NULL);
	double alpha_val=2;
	double beta_val=2;
	double x_val=0.65;
 	int n_val=17;
 	double p_val[]={-28471492267.0/4194304.0,26980769367.0/2097152.0,-45904273683.0/4194304.0,17507317561.0/2097152.0,-11950694063.0/2097152.0,14559064751.0/4194304.0,-15766137527.0/8388608.0,3774819027.0/4194304.0,-1588096377.0/4194304.0,582044911.0/4194304.0,-367619987.0/8388608.0,49300931.0/4194304.0,-5507631.0/2097152.0,498871.0/1048576.0,-35209.0/524288.0,1817.0/262144.0,-61.0/131072.0,1.0/65536.0};
	res_val=JacobVal(p_val,n_val,x_val,alpha_val,beta_val);
	gettimeofday(&et,NULL);
	elapsed = ((et.tv_sec - st.tv_sec) * 1000000) + (et.tv_usec - st.tv_usec);
	printf("JacobVal time: %d micro seconds\n",elapsed);	
 	printf("the result of JacobVal is %14.14e\n",res_val);
 	//Der
	double res_der;
	gettimeofday(&st,NULL);
	double alpha_der=2;
	double beta_der=2;
	double x_der=0.65;
 	int n_der=17;
 	double p_der[]={-28471492267.0/4194304.0,26980769367.0/2097152.0,-45904273683.0/4194304.0,17507317561.0/2097152.0,-11950694063.0/2097152.0,14559064751.0/4194304.0,-15766137527.0/8388608.0,3774819027.0/4194304.0,-1588096377.0/4194304.0,582044911.0/4194304.0,-367619987.0/8388608.0,49300931.0/4194304.0,-5507631.0/2097152.0,498871.0/1048576.0,-35209.0/524288.0,1817.0/262144.0,-61.0/131072.0,1.0/65536.0};
	res_der=JacobDer(p_der,n_der,x_der,alpha_der,beta_der);
	gettimeofday(&et,NULL);
	elapsed = ((et.tv_sec - st.tv_sec) * 1000000) + (et.tv_usec - st.tv_usec);
	printf("JacobDer time: %d micro seconds\n",elapsed);	
 	printf("the result of JacobDer is %14.14e\n",res_der);
 	//DerK
 	double res_derK;
	gettimeofday(&st,NULL);
	double alpha_derK=2;
	double beta_derK=2;
	double x_derK=0.65;
 	int n_derK=17;
 	int k=4;
 	double p_derK[]={-28471492267.0/4194304.0,26980769367.0/2097152.0,-45904273683.0/4194304.0,17507317561.0/2097152.0,-11950694063.0/2097152.0,14559064751.0/4194304.0,-15766137527.0/8388608.0,3774819027.0/4194304.0,-1588096377.0/4194304.0,582044911.0/4194304.0,-367619987.0/8388608.0,49300931.0/4194304.0,-5507631.0/2097152.0,498871.0/1048576.0,-35209.0/524288.0,1817.0/262144.0,-61.0/131072.0,1.0/65536.0};
	res_derK=JacobDerK(p_val,n_derK,x_val,alpha_derK,beta_derK,k);
	gettimeofday(&et,NULL);
	elapsed = ((et.tv_sec - st.tv_sec) * 1000000) + (et.tv_usec - st.tv_usec);
	printf("JacobDerK time: %d micro seconds\n",elapsed);	
 	printf("the result of JacobDerK is %14.14e\n",res_derK);
}


//----------------------- The three-term recurrence coefficients of laguerre polynomial ----------------------------------
void RecurCoefLague (double n, double alpha,  double *A, double *B, double *C)
{
    int i;
    double j;
    for (i=1;i<=n+2;i++)
    {
        j=1.0*i;
        *(A+i-1)=-1/j;
        *(B+i-1)=(2*j+alpha-1)/j;
        *(C+i-1)=(j-1+alpha)/j;
    }
}

/* LagueVal evaluates a series of Laguerre polynomial at the point x, which is in (0, +infty).*/
double LagueVal(double *P, unsigned int n, double x, double alpha)
{
    assert ( 0 < n);
    assert (x>0);
    assert (alpha>-1.0);
    double  t,b1=0,b2=0;
    int j;

    double *A=(double *) malloc(sizeof(double)*(n+2));
    double *B=(double *) malloc(sizeof(double)*(n+2));
    double *C=(double *) malloc(sizeof(double)*(n+2));

    RecurCoefLague(n,alpha,A,B,C);

    for(j=n; j>=0; j--) 
    {
        t=(*(A+j)*x+*(B+j))*b1-*(C+j+1)*b2+P[j];

        b2=b1;
        b1=t;
    }
    free(A);
    free(B);
    free(C);

    return b1;
}

/*LagueDer evaluates  the first derivative of a series of Laguerre polynomial at the point x, which is in (0, +infty). */
double LagueDer(double *P, unsigned int n, double x, double alpha)
{
    assert ( 0 < n);
    assert (x>0);
    assert (alpha>-1.0);
    double  t,b1=0,b2=0;
    double A1,A2;
    int i;
    double j;
    double C=1;

    for(i=n-1; i>=0; i--) 
    {
        j=1.0*i;
//-------------recurrence coefficients-----------------------//
        A1=-x/(j+1)+(2*j+alpha+2)/(j+1);
        A2=-(j+alpha+2)/(j+2);
//--------------iteration-----------------------------------//
        t=A1*b1+A2*b2-P[i+1];

        b2=b1;
        b1=t;
    }
    return  C*b1;
}
/*LagueDerK evaluates  the k-th derivative of a series of Laguerre polynomial at the point x, which is in (0, +infty). */
double LagueDerK(double *P, unsigned int n, double x, double alpha, unsigned int k)
{
    assert ( 0 < n);
    assert (x>0);
    assert (alpha>-1.0);
    double  t,b1=0,b2=0;
    double A1,A2;
    int i;
    double j;
    int C=1;
    for(i=k;i>0;i--)
    {
        C=-C;
    }

    for(i=n-k; i>=0; i--) 
    {
        j=1.0*i;
//-------------recurrence coefficients-----------------------//
        A1=-x/(j+1)+(2*j+alpha+k+1)/(j+1);
        A2=-(j+alpha+k+1)/(j+2);
//--------------iteration-----------------------------------//
        t=A1*b1+A2*b2+P[i+k];

        b2=b1;
        b1=t;
    }
    return  C*b1;
}

void lague(){
	struct timeval st, et;
	int elapsed;
 	//Val
	double res_val;
	gettimeofday(&st,NULL);
	double alpha_val=2;
	double x_val=0.65;
 	int n_val=17;
 	double p_val[]={-28471492267.0/4194304.0,26980769367.0/2097152.0,-45904273683.0/4194304.0,17507317561.0/2097152.0,-11950694063.0/2097152.0,14559064751.0/4194304.0,-15766137527.0/8388608.0,3774819027.0/4194304.0,-1588096377.0/4194304.0,582044911.0/4194304.0,-367619987.0/8388608.0,49300931.0/4194304.0,-5507631.0/2097152.0,498871.0/1048576.0,-35209.0/524288.0,1817.0/262144.0,-61.0/131072.0,1.0/65536.0};
	res_val=LagueVal(p_val,n_val,x_val,alpha_val);
	gettimeofday(&et,NULL);
	elapsed = ((et.tv_sec - st.tv_sec) * 1000000) + (et.tv_usec - st.tv_usec);
	printf("LagueVal time: %d micro seconds\n",elapsed);	
 	printf("the result of LagueVal is %14.14e\n",res_val);
 	//Der
	double res_der;
	gettimeofday(&st,NULL);
	double alpha_der=2;
	double x_der=0.65;
 	int n_der=17;
 	double p_der[]={-28471492267.0/4194304.0,26980769367.0/2097152.0,-45904273683.0/4194304.0,17507317561.0/2097152.0,-11950694063.0/2097152.0,14559064751.0/4194304.0,-15766137527.0/8388608.0,3774819027.0/4194304.0,-1588096377.0/4194304.0,582044911.0/4194304.0,-367619987.0/8388608.0,49300931.0/4194304.0,-5507631.0/2097152.0,498871.0/1048576.0,-35209.0/524288.0,1817.0/262144.0,-61.0/131072.0,1.0/65536.0};
	res_der=LagueDer(p_der,n_der,x_der,alpha_der);
	gettimeofday(&et,NULL);
	elapsed = ((et.tv_sec - st.tv_sec) * 1000000) + (et.tv_usec - st.tv_usec);
	printf("LagueDer time: %d micro seconds\n",elapsed);	
 	printf("the result of LagueDer is %14.14e\n",res_der);
 	//DerK
 	double res_derK;
	gettimeofday(&st,NULL);
	double alpha_derK=2;
	double x_derK=0.65;
 	int n_derK=17;
 	int k=4;
 	double p_derK[]={-28471492267.0/4194304.0,26980769367.0/2097152.0,-45904273683.0/4194304.0,17507317561.0/2097152.0,-11950694063.0/2097152.0,14559064751.0/4194304.0,-15766137527.0/8388608.0,3774819027.0/4194304.0,-1588096377.0/4194304.0,582044911.0/4194304.0,-367619987.0/8388608.0,49300931.0/4194304.0,-5507631.0/2097152.0,498871.0/1048576.0,-35209.0/524288.0,1817.0/262144.0,-61.0/131072.0,1.0/65536.0};
	res_derK=LagueDerK(p_val,n_derK,x_val,alpha_derK,k);
	gettimeofday(&et,NULL);
	elapsed = ((et.tv_sec - st.tv_sec) * 1000000) + (et.tv_usec - st.tv_usec);
	printf("LagueDerK time: %d micro seconds\n",elapsed);	
 	printf("the result of LagueDerK is %14.14e\n",res_derK);
}

int main(void)
{
 	/*struct timeval st, et;
 	double res;
	gettimeofday(&st,NULL);
	double x=0.65;
 	int n=17;
 	double p[]={-28471492267.0/4194304.0,26980769367.0/2097152.0,-45904273683.0/4194304.0,17507317561.0/2097152.0,-11950694063.0/2097152.0,14559064751.0/4194304.0,-15766137527.0/8388608.0,3774819027.0/4194304.0,-1588096377.0/4194304.0,582044911.0/4194304.0,-367619987.0/8388608.0,49300931.0/4194304.0,-5507631.0/2097152.0,498871.0/1048576.0,-35209.0/524288.0,1817.0/262144.0,-61.0/131072.0,1.0/65536.0};
	int i=0;
	res+=Herm2DerK(p,n,x,4);
	
	gettimeofday(&et,NULL);
	int elapsed = ((et.tv_sec - st.tv_sec) * 1000000) + (et.tv_usec - st.tv_usec);
	printf("Sorting time: %d micro seconds\n",elapsed);	
	
	
 	 printf("the result of Herm2DerK is %14.14e\n",res);
*/
	printf("legen---------------------------------------------------------------------------\n");
	legen();
	//printf("herm1---------------------------------------------------------------------------\n");
	//herm1();
	//printf("herm2---------------------------------------------------------------------------\n");
	//herm2();
	printf("cheb1---------------------------------------------------------------------------\n");
	cheb1();
	printf("cheb2---------------------------------------------------------------------------\n");
	cheb2();
	printf("gegen---------------------------------------------------------------------------\n");
	gegen();
	//printf("jacob---------------------------------------------------------------------------\n");
	//jacob();
	//printf("lague---------------------------------------------------------------------------\n");
	//lague();
}
