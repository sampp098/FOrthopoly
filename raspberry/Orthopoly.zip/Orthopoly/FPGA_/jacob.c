#include<stdio.h>
#include<assert.h>
#include<stdlib.h>
#include<math.h>
#include<sys/time.h>

//----------------------- The three-term recurrence coefficients of jacobi polynomial ----------------------------------
void RecurCoefJacob (double n, double alpha, double beta,  double *A, double *B, double *C)
{
    int i;
    double j;
    for (i=1;i<=n+2;i++)
    {
        j=1.0*i;
        A[i-1]=(2*j+alpha+beta-1)*(2*j+alpha+beta)/(2*j*(j+alpha+beta));
        B[i-1]=(alpha*alpha-beta*beta)*(2*j+alpha+beta-1)/(2*j*(j+alpha+beta)*(2*j+alpha+beta-2));
        C[i-1]=(j-1+alpha)*(j-1+beta)*(2*j+alpha+beta)/(j*(j+alpha+beta)*(2*j+alpha+beta-2));
    }
}

/* JacobVal evaluates a series of Jacobobi polynomial at the point x, which is in [-1, 1].*/
double JacobVal(double *P, unsigned int n, double x, double alpha, double beta)
{
    assert ( 0 < n);
    assert (fabs(x)<=1.0);
    assert (alpha>-1.0);
    assert (beta>-1.0);

    double  t,b1=0,b2=0;
    int j;

    double A[n+2];
    double B[n+2];
    double C[n+2];

    RecurCoefJacob(n,alpha,beta,A,B,C);

    for(j=n; j>=0; j--) 
    {
        t=(*(A+j)*x+*(B+j))*b1-*(C+j+1)*b2+P[j];

        b2=b1;
        b1=t;
    }

    return b1;
}

/*JacobDer evaluates  the first derivative of a series of Jacobobi polynomial at the point x, which is in [-1, 1]. */
double JacobDer(double *P, unsigned int n, double x, double alpha, double beta)
{
    assert ( 0 < n);
    assert (fabs(x)<=1.0);
    assert (alpha>-1.0);
    assert (beta>-1.0);
    double  t,b1=0,b2=0;
    double Ac, A1, A2;
    double a10,a11,a12,a20,a21;
    int i;
    double j;
    double C=0.5;

    for(i=n-1; i>=0; i--) 
    {
        j=1.0*i;
//-------------recurrence coefficients-----------------------//
        Ac=j+2+alpha+beta;
        a10=(2*j+3+alpha+beta)/((2*j+2)*(j+3+alpha+beta));
        a11=(2*j+4+alpha+beta)*x;
        a12=((alpha-beta)*(alpha+beta+2))/(alpha+beta+2*j+2);
        A1=a10*(a11+a12);
        a20=-(j+2+alpha)*(j+2+beta)/((j+2)*(alpha+beta+j+4));
        a21=(alpha+beta+2*j+6)/(alpha+beta+2*j+4);
        A2=a20*a21;
//--------------iteration-----------------------------------//
        t=A1*b1+A2*b2+Ac*P[i+1];

        b2=b1;
        b1=t;
    }
    return  C*b1;
}


/*JacobDerK evaluates the k-th derivative of a series of Jacobobi polynomial at the point x, which is in [-1, 1]. */
double JacobDerK(double *P, unsigned int n, double x, double alpha, double beta, unsigned int k)
{
    assert ( 0 < n);
    assert (fabs(x)<=1.0);
    assert (alpha>-1.0);
    assert (beta>-1.0);
    double  t,b1=0,b2=0;
    double A1, A2,s;
    double a10,a11,a12,a20,a21;
    int i,j;
    double C=1.0;
    for(i=k;i>0;i--)
    {
        C=C/2.0;
    }

    for(i=n-k; i>=0; i--) 
    {
//-------------recurrence coefficients-----------------------//
        s=1.0;
        for(j=1;j<=k;j++)
        {
            s=s*(alpha+beta+i+k+j);
        }
        a10=(2*i+1+2*k+alpha+beta)/((2*i+2)*(i+1+2*k+alpha+beta));
        a11=(2*i+2+2*k+alpha+beta)*x;
        a12=((alpha-beta)*(alpha+beta+2*k))/(alpha+beta+2*i+2*k);
        A1=a10*(a11+a12);
        
        a20=-(i+1+k+alpha)*(i+1+k+beta)/((i+2)*(alpha+beta+i+2+2*k));
        a21=(alpha+beta+2*i+4+2*k)/(alpha+beta+2*i+2+2*k);
        A2=a20*a21;
//--------------iteration-----------------------------------//
    t=A1*b1+A2*b2+s*P[i+k];

    b2=b1;
    b1=t;
    }
    return  C*b1;
}

void jacob(){
	struct timeval st, et;
	int elapsed;
 	//Val
	double res_val;
	gettimeofday(&st,NULL);
	double alpha_val=2;
	double beta_val=2;
	double x_val=0.65;
 	int n_val=17;
 	double p_val[]={-28471492267.0/4194304.0,26980769367.0/2097152.0,-45904273683.0/4194304.0,17507317561.0/2097152.0,-11950694063.0/2097152.0,14559064751.0/4194304.0,-15766137527.0/8388608.0,3774819027.0/4194304.0,-1588096377.0/4194304.0,582044911.0/4194304.0,-367619987.0/8388608.0,49300931.0/4194304.0,-5507631.0/2097152.0,498871.0/1048576.0,-35209.0/524288.0,1817.0/262144.0,-61.0/131072.0,1.0/65536.0};
	res_val=JacobVal(p_val,n_val,x_val,alpha_val,beta_val);
	gettimeofday(&et,NULL);
	elapsed = ((et.tv_sec - st.tv_sec) * 1000000) + (et.tv_usec - st.tv_usec);
	printf("JacobVal time: %d micro seconds\n",elapsed);	
 	printf("the result of JacobVal is %14.14e\n",res_val);
 	//Der
	double res_der;
	gettimeofday(&st,NULL);
	double alpha_der=2;
	double beta_der=2;
	double x_der=0.65;
 	int n_der=17;
 	double p_der[]={-28471492267.0/4194304.0,26980769367.0/2097152.0,-45904273683.0/4194304.0,17507317561.0/2097152.0,-11950694063.0/2097152.0,14559064751.0/4194304.0,-15766137527.0/8388608.0,3774819027.0/4194304.0,-1588096377.0/4194304.0,582044911.0/4194304.0,-367619987.0/8388608.0,49300931.0/4194304.0,-5507631.0/2097152.0,498871.0/1048576.0,-35209.0/524288.0,1817.0/262144.0,-61.0/131072.0,1.0/65536.0};
	res_der=JacobDer(p_der,n_der,x_der,alpha_der,beta_der);
	gettimeofday(&et,NULL);
	elapsed = ((et.tv_sec - st.tv_sec) * 1000000) + (et.tv_usec - st.tv_usec);
	printf("JacobDer time: %d micro seconds\n",elapsed);	
 	printf("the result of JacobDer is %14.14e\n",res_der);
 	//DerK
 	double res_derK;
	gettimeofday(&st,NULL);
	double alpha_derK=2;
	double beta_derK=2;
	double x_derK=0.65;
 	int n_derK=17;
 	int k=4;
 	double p_derK[]={-28471492267.0/4194304.0,26980769367.0/2097152.0,-45904273683.0/4194304.0,17507317561.0/2097152.0,-11950694063.0/2097152.0,14559064751.0/4194304.0,-15766137527.0/8388608.0,3774819027.0/4194304.0,-1588096377.0/4194304.0,582044911.0/4194304.0,-367619987.0/8388608.0,49300931.0/4194304.0,-5507631.0/2097152.0,498871.0/1048576.0,-35209.0/524288.0,1817.0/262144.0,-61.0/131072.0,1.0/65536.0};
	res_derK=JacobDerK(p_val,n_derK,x_val,alpha_derK,beta_derK,k);
	gettimeofday(&et,NULL);
	elapsed = ((et.tv_sec - st.tv_sec) * 1000000) + (et.tv_usec - st.tv_usec);
	printf("JacobDerK time: %d micro seconds\n",elapsed);	
 	printf("the result of JacobDerK is %14.14e\n",res_derK);
}
int main(void)
{
 	/*struct timeval st, et;
 	double res;
	gettimeofday(&st,NULL);
	double x=0.65;
 	int n=17;
 	double p[]={-28471492267.0/4194304.0,26980769367.0/2097152.0,-45904273683.0/4194304.0,17507317561.0/2097152.0,-11950694063.0/2097152.0,14559064751.0/4194304.0,-15766137527.0/8388608.0,3774819027.0/4194304.0,-1588096377.0/4194304.0,582044911.0/4194304.0,-367619987.0/8388608.0,49300931.0/4194304.0,-5507631.0/2097152.0,498871.0/1048576.0,-35209.0/524288.0,1817.0/262144.0,-61.0/131072.0,1.0/65536.0};
	int i=0;
	res+=Herm2DerK(p,n,x,4);
	
	gettimeofday(&et,NULL);
	int elapsed = ((et.tv_sec - st.tv_sec) * 1000000) + (et.tv_usec - st.tv_usec);
	printf("Sorting time: %d micro seconds\n",elapsed);	
	
	
 	 printf("the result of Herm2DerK is %14.14e\n",res);
*/
	struct timeval st, et;
	gettimeofday(&st,NULL);
	int i=0;
	for(i=0;i<100;i++){
	//printf("jacob---------------------------------------------------------------------------\n");
		jacob();
	}
	gettimeofday(&et,NULL);
	int elapsed = ((et.tv_sec - st.tv_sec) * 1000000) + (et.tv_usec - st.tv_usec);
	//printf("jacob---------------------------------------------------------------------------\n");
	//jacob();
	 printf("cheb1 time: %d micro seconds\n",elapsed);
}
