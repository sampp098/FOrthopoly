#include<stdio.h>
#include<assert.h>
#include<stdlib.h>
#include<math.h>
#include<sys/time.h>

void RecurCoefGegen (double n, double lambda,  double *A, double *C)
{
    int i;
    double j;
    for (i=1;i<=n+2;i++)
    {
        j=1.0*i;
        A[i-1]=2*(j+lambda-1)/j;
        C[i-1]=(j+2*lambda-2)/j;
    }
}

/*GegenVal evaluates a series of Gegenbauer polynomial at the point x, which is in [-1, 1] */
double GegenVal(double *P, unsigned int n, double x, double lambda)
{
    assert ( 0 < n);
    assert (fabs(x)<=1.0);
    assert (lambda>-0.5);
    assert (lambda!=0);
    double  t,b1=0,b2=0;
    int j;

    double *A=(double *) malloc(sizeof(double)*(n+2));
    double *C=(double *) malloc(sizeof(double)*(n+2));

    RecurCoefGegen(n,lambda,A,C);

    for(j=n; j>=0; j--)
    {
        t=*(A+j)*x*b1-*(C+j+1)*b2+P[j];
        b2=b1;
        b1=t;
    }
    free(A);
    free(C);
    return b1;
}

/*GegenDer evaluates  the first derivative of a series of Gegenbauer polynomial at the point x, which is in [-1, 1] */
double GegenDer(double *P, unsigned int n, double x, double lambda)
{
    assert ( 0 < n);
    assert (fabs(x)<=1.0);
    assert (lambda>-0.5);
    assert (lambda!=0);
    double  t,b1=0,b2=0;
    double A1, A2;
    int i;
    double j;
    double C=2*lambda;

    for(i=n-1; i>=0; i--)
    {
        j=1.0*i;
//-------------recurrence coefficients-----------------------//
        A1=2*(j+1+lambda)*x/(j+1);
        A2=-(j+2*lambda+2)/(j+2);
//--------------iteration------------------------------------//
        t=A1*b1+A2*b2+P[i+1];
        b2=b1;
        b1=t;
    }
    return  C*b1;
}

/*GegenDerK evaluates  the k-th derivative of a series of Gegenbauer polynomial at the point x, which is in [-1, 1] */
double GegenDerK(double *P, unsigned int n, double x, double lambda, unsigned int k)
{
    assert ( 0 < n);
    assert (fabs(x)<=1.0);
    assert (lambda>-0.5);
    assert (lambda!=0);
    double  s=1.0,t,b1=0,b2=0;
    double A1, A2;
    int i;
    double j;
    for(i=1;i<=k;i++)
    {
        s=2*s*(lambda+i-1);
     }

    for(i=n-k; i>=0; i--)
    {
        j=1.0*i;
//-------------recurrence coefficients-----------------------//
       	A1=2*(j+k+lambda)*x/(j+1);
       	A2=-(j+2*lambda+2*k)/(j+2);
//--------------iteration-----------------------------------//
        t=A1*b1+A2*b2+P[i+k];

        b2=b1;
        b1=t;
    }
    return  s*b1;
}

void gegen(){
	struct timeval st, et;
	int elapsed;
 	//Val
	double res_val;
	gettimeofday(&st,NULL);
	double lambda_val=0.1;
	double x_val=0.65;
 	int n_val=17;
 	double p_val[]={-5519.293981327233066492480,56938.39132709945770922845,-91563.06755535588464893715,102138.3111747267800498606,-91390.68590697961077663426,68657.12752193417008543252,-44100.88354121754231424355,24386.84606480670093305547,-11616.31191831442987520578,4748.151213920654766176631,-1652.503681640035662508434,483.7838889893579801893316,-117.0476967480900562237535,22.80826826011093041346609,-3.443497607139100737840257,0.3782868329050993116058965,-0.02691969449476297499191505,0.0009319515454861432627790780};
	res_val=GegenVal(p_val,n_val,x_val,lambda_val);
	gettimeofday(&et,NULL);
	elapsed = ((et.tv_sec - st.tv_sec) * 1000000) + (et.tv_usec - st.tv_usec);
	printf("GegenVal time: %d micro seconds\n",elapsed);	
 	printf("the result of GegenVal is %14.14e\n",res_val);
 	//Der
	double res_der;
	gettimeofday(&st,NULL);
	double lambda_der=0.1;
	double x_der=0.65;
 	int n_der=17;
 	double p_der[]={-5519.293981327233066492480,56938.39132709945770922845,-91563.06755535588464893715,102138.3111747267800498606,-91390.68590697961077663426,68657.12752193417008543252,-44100.88354121754231424355,24386.84606480670093305547,-11616.31191831442987520578,4748.151213920654766176631,-1652.503681640035662508434,483.7838889893579801893316,-117.0476967480900562237535,22.80826826011093041346609,-3.443497607139100737840257,0.3782868329050993116058965,-0.02691969449476297499191505,0.0009319515454861432627790780};
	res_der=GegenDer(p_der,n_der,x_der,lambda_der);
	gettimeofday(&et,NULL);
	elapsed = ((et.tv_sec - st.tv_sec) * 1000000) + (et.tv_usec - st.tv_usec);
	printf("GegenDer time: %d micro seconds\n",elapsed);	
 	printf("the result of GegenDer is %14.14e\n",res_der);
 	//DerK
 	double res_derK;
	gettimeofday(&st,NULL);
	double lambda_derK=0.1;
	double x_derK=0.65;
 	int n_derK=17;
 	int k=4;
 	double p_derK[]={-5519.293981327233066492480,56938.39132709945770922845,-91563.06755535588464893715,102138.3111747267800498606,-91390.68590697961077663426,68657.12752193417008543252,-44100.88354121754231424355,24386.84606480670093305547,-11616.31191831442987520578,4748.151213920654766176631,-1652.503681640035662508434,483.7838889893579801893316,-117.0476967480900562237535,22.80826826011093041346609,-3.443497607139100737840257,0.3782868329050993116058965,-0.02691969449476297499191505,0.0009319515454861432627790780};
	res_derK=GegenDerK(p_val,n_derK,x_val,lambda_derK,k);
	gettimeofday(&et,NULL);
	elapsed = ((et.tv_sec - st.tv_sec) * 1000000) + (et.tv_usec - st.tv_usec);
	printf("GegenDerK time: %d micro seconds\n",elapsed);	
 	printf("the result of GegenDerK is %14.14e\n",res_derK);
}
int main(void)
{
 	/*struct timeval st, et;
 	double res;
	gettimeofday(&st,NULL);
	double x=0.65;
 	int n=17;
 	double p[]={-28471492267.0/4194304.0,26980769367.0/2097152.0,-45904273683.0/4194304.0,17507317561.0/2097152.0,-11950694063.0/2097152.0,14559064751.0/4194304.0,-15766137527.0/8388608.0,3774819027.0/4194304.0,-1588096377.0/4194304.0,582044911.0/4194304.0,-367619987.0/8388608.0,49300931.0/4194304.0,-5507631.0/2097152.0,498871.0/1048576.0,-35209.0/524288.0,1817.0/262144.0,-61.0/131072.0,1.0/65536.0};
	int i=0;
	res+=Herm2DerK(p,n,x,4);
	
	gettimeofday(&et,NULL);
	int elapsed = ((et.tv_sec - st.tv_sec) * 1000000) + (et.tv_usec - st.tv_usec);
	printf("Sorting time: %d micro seconds\n",elapsed);	
	
	
 	 printf("the result of Herm2DerK is %14.14e\n",res);
*/
	struct timeval st, et;
	gettimeofday(&st,NULL);
	int i=0;
	for(i=0;i<100;i++){
	//printf("gegen---------------------------------------------------------------------------\n");
		gegen();
	}
	gettimeofday(&et,NULL);
	int elapsed = ((et.tv_sec - st.tv_sec) * 1000000) + (et.tv_usec - st.tv_usec);
	//printf("gegen---------------------------------------------------------------------------\n");
	//gegen();
	 printf("cheb1 time: %d micro seconds\n",elapsed);
}
