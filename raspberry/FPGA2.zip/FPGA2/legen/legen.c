#include<stdio.h>
#include<assert.h>
#include<stdlib.h>
#include<math.h>
#include<sys/time.h>

/* LegenVal evaluates a series of legendre polynomial at the point x, which is in [-1, 1].*/


double LegenVal(double *P, unsigned int n, double x)
{
    assert ( 0 < n);
    assert (fabs(x)<=1.0);
    double  t,b1=0,b2=0;
    int j;
    double i;

    for(j=n; j>=1; j--) 
    {
        i=1.0*j;
        t=(2*i+1)/(i+1)*x*b1-(i+1)/(i+2)*b2+P[j];
        b2=b1;
        b1=t;
    }
    return x*b1-b2/2+P[0];
}

/*LegenDer evaluates  the first derivative of a series of legendre polynomial at the point x, which is in [-1, 1]. */
double LegenDer(double *P, unsigned int n, double x)
{
    assert ( 0 < n);
    assert (fabs(x)<=1.0);
    double  t,b1=0,b2=0;
    int j;
    double i;

    for(j=n-1; j>=0; j--) 
    {
        i=1.0*j;
        t=(2*i+3)/(i+1)*x*b1-(i+3)/(i+2)*b2+P[j+1];
        b2=b1;
        b1=t;
    }
    return  b1;
}

/*LegenDerK evaluates  the k-th derivative of a series of legendre polynomial at the point x, which is in [-1, 1]. */
double LegenDerK(double *P, unsigned int n, double x, unsigned int k)
{
    assert ( 0 < n);
    assert (fabs(x)<=1.0);
    double  s=1.0,t,b1=0,b2=0;
    int j;
    double i;

    for(j=2*k-1;j>0;j=j-2)
    {
        s=j*s;
    }
    double  A1,A2;

    for(j=n-k; j>=0; j--) 
    {
        i=1.0*j;
        A1=(2*i+2*k+1)/(i+1)*x;
        A2=-(i+2*k+1)/(i+2);
        t=A1*b1+A2*b2+P[j+k];

        b2=b1;
        b1=t;
    }
    return  s*b1;
}

void legen(){
	struct timeval st, et;
	int elapsed;
 	//Val
	double res_val;
	gettimeofday(&st,NULL);
	double x_val=0.65;
 	int n_val=17;
 	double p_val[]={-2699.915949654920243155538,7294.954964701191481377250,-9855.340953819572240624893,10051.56898107052905814518,-8442.942168319296802268938,6027.152042271538081875930,-3704.426571905112506135507,1968.958712915444137681290,-904.3828105802791157482192,357.3311403326828518644365,-120.4460531417831357257847,34.20556390836229632004353,-8.038700860731022120912915,1.523326182709104850355380,-0.2238790056018962788199805,0.02396245039753007133932317,-0.001662712703037941393453644,0.00005616714545781420772147874};
	res_val=LegenVal(p_val,n_val,x_val);
	gettimeofday(&et,NULL);
	elapsed = ((et.tv_sec - st.tv_sec) * 1000000) + (et.tv_usec - st.tv_usec);
	printf("LegenVal time: %d micro seconds\n",elapsed);	
 	printf("the result of LegenVal is %14.14e\n",res_val);
 	//Der
	double res_der;
	gettimeofday(&st,NULL);
	double x_der=0.65;
 	int n_der=17;
 	double p_der[]={-2699.915949654920243155538,7294.954964701191481377250,-9855.340953819572240624893,10051.56898107052905814518,-8442.942168319296802268938,6027.152042271538081875930,-3704.426571905112506135507,1968.958712915444137681290,-904.3828105802791157482192,357.3311403326828518644365,-120.4460531417831357257847,34.20556390836229632004353,-8.038700860731022120912915,1.523326182709104850355380,-0.2238790056018962788199805,0.02396245039753007133932317,-0.001662712703037941393453644,0.00005616714545781420772147874};
	res_der=LegenDer(p_der,n_der,x_der);
	gettimeofday(&et,NULL);
	elapsed = ((et.tv_sec - st.tv_sec) * 1000000) + (et.tv_usec - st.tv_usec);
	printf("LegenDer time: %d micro seconds\n",elapsed);	
 	printf("the result of LegenDer is %14.14e\n",res_der);
 	//DerK
 	double res_derK;
	gettimeofday(&st,NULL);
	double x_derK=0.65;
 	int n_derK=17;
 	int k=4;
 	double p_derK[]={-2699.915949654920243155538,7294.954964701191481377250,-9855.340953819572240624893,10051.56898107052905814518,-8442.942168319296802268938,6027.152042271538081875930,-3704.426571905112506135507,1968.958712915444137681290,-904.3828105802791157482192,357.3311403326828518644365,-120.4460531417831357257847,34.20556390836229632004353,-8.038700860731022120912915,1.523326182709104850355380,-0.2238790056018962788199805,0.02396245039753007133932317,-0.001662712703037941393453644,0.00005616714545781420772147874};
	res_derK=LegenDerK(p_val,n_derK,x_val,k);
	gettimeofday(&et,NULL);
	elapsed = ((et.tv_sec - st.tv_sec) * 1000000) + (et.tv_usec - st.tv_usec);
	printf("LegenDerk time: %d micro seconds\n",elapsed);	
 	printf("the result of LegenDerK is %14.14e\n",res_derK);
}
int main(void)
{
 	/*struct timeval st, et;
 	double res;
	gettimeofday(&st,NULL);
	double x=0.65;
 	int n=17;
 	double p[]={-28471492267.0/4194304.0,26980769367.0/2097152.0,-45904273683.0/4194304.0,17507317561.0/2097152.0,-11950694063.0/2097152.0,14559064751.0/4194304.0,-15766137527.0/8388608.0,3774819027.0/4194304.0,-1588096377.0/4194304.0,582044911.0/4194304.0,-367619987.0/8388608.0,49300931.0/4194304.0,-5507631.0/2097152.0,498871.0/1048576.0,-35209.0/524288.0,1817.0/262144.0,-61.0/131072.0,1.0/65536.0};
	int i=0;
	res+=Herm2DerK(p,n,x,4);
	
	gettimeofday(&et,NULL);
	int elapsed = ((et.tv_sec - st.tv_sec) * 1000000) + (et.tv_usec - st.tv_usec);
	printf("Sorting time: %d micro seconds\n",elapsed);	
	
	
 	 printf("the result of Herm2DerK is %14.14e\n",res);
*/
	struct timeval st, et;
	gettimeofday(&st,NULL);
	int i=0;
	for(i=0;i<100;i++){
	//printf("legen---------------------------------------------------------------------------\n");
		legen();
	}
	gettimeofday(&et,NULL);
	int elapsed = ((et.tv_sec - st.tv_sec) * 1000000) + (et.tv_usec - st.tv_usec);
	//printf("legen---------------------------------------------------------------------------\n");
	//legen();
	 printf("cheb1 time: %d micro seconds\n",elapsed);
}
