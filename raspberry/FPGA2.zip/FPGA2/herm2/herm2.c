#include<stdio.h>
#include<assert.h>
#include<stdlib.h>
#include<math.h>
#include<sys/time.h>

/*Herm2Val evaluates a series of Hermite polynomial H at the point x. */
double Herm2Val(double *P, unsigned int n, double x)
{
    assert ( 0 < n);
    double  xx,t,b1=0,b2=0;
    int i;
    xx=2*x;

    for(i=n; i>=0; i--) 
    {
        t=xx*b1-2*(i+1)*b2+P[i];
        b2=b1;
        b1=t;
    }
    return b1;
}

/*Herm2Der evaluates  the first  derivative of a series of Hermite polynomial H at the point x. */
double Herm2Der(double *P, unsigned int n, double x)
{
    assert ( 0 < n);
    double  xx,t,b1=0,b2=0;
    int i;
    xx=2*x;

    for(i=n-1; i>=0; i--) 
    {
        t=xx*b1-2*(i+1)*b2+2*(i+1)*P[i+1];
        b2=b1;
        b1=t;
    }
    return  b1;
}

/*Herm2DerK evaluates  the k-th  derivative of a series of Hermite polynomial H at the point x. */
double Herm2DerK(double *P, unsigned int n, double x, unsigned int k)
{
    assert ( 0 < n);
    double  xx,C=1.0,s,t,b1=0,b2=0;
    int i,j;
    for(i=k;i>0;i--)
        {
            C=2*C;
        }
        xx=2*x;

    for(i=n-k; i>=0; i--) 
    {
        s=1.0;
        for(j=i+k;j>=i+1;j--)
        {
            s=s*j;
        }
        t=xx*b1-2*(i+1)*b2+s*P[i+k];

        b2=b1;
        b1=t;
    }
return  C*b1;
}

void herm2(){
	struct timeval st, et;
	int elapsed;
 	//Val
	double res_val;
	gettimeofday(&st,NULL);
	double x_val=0.65;
 	int n_val=17;
 	double p_val[]={-28471492267.0/4194304.0,26980769367.0/2097152.0,-45904273683.0/4194304.0,17507317561.0/2097152.0,-11950694063.0/2097152.0,14559064751.0/4194304.0,-15766137527.0/8388608.0,3774819027.0/4194304.0,-1588096377.0/4194304.0,582044911.0/4194304.0,-367619987.0/8388608.0,49300931.0/4194304.0,-5507631.0/2097152.0,498871.0/1048576.0,-35209.0/524288.0,1817.0/262144.0,-61.0/131072.0,1.0/65536.0};
	res_val=Herm2Val(p_val,n_val,x_val);
	gettimeofday(&et,NULL);
	elapsed = ((et.tv_sec - st.tv_sec) * 1000000) + (et.tv_usec - st.tv_usec);
	printf("Herm2Val time: %d micro seconds\n",elapsed);	
 	printf("the result of Herm2Val is %14.14e\n",res_val);
 	//Der
	double res_der;
	gettimeofday(&st,NULL);
	double x_der=0.65;
 	int n_der=17;
 	double p_der[]={-28471492267.0/4194304.0,26980769367.0/2097152.0,-45904273683.0/4194304.0,17507317561.0/2097152.0,-11950694063.0/2097152.0,14559064751.0/4194304.0,-15766137527.0/8388608.0,3774819027.0/4194304.0,-1588096377.0/4194304.0,582044911.0/4194304.0,-367619987.0/8388608.0,49300931.0/4194304.0,-5507631.0/2097152.0,498871.0/1048576.0,-35209.0/524288.0,1817.0/262144.0,-61.0/131072.0,1.0/65536.0};
	res_der=Herm2Der(p_der,n_der,x_der);
	gettimeofday(&et,NULL);
	elapsed = ((et.tv_sec - st.tv_sec) * 1000000) + (et.tv_usec - st.tv_usec);
	printf("Herm2Der time: %d micro seconds\n",elapsed);	
 	printf("the result of Herm2Der is %14.14e\n",res_der);
 	//DerK
 	double res_derK;
	gettimeofday(&st,NULL);
	double x_derK=0.65;
 	int n_derK=17;
 	int k=4;
 	double p_derK[]={-28471492267.0/4194304.0,26980769367.0/2097152.0,-45904273683.0/4194304.0,17507317561.0/2097152.0,-11950694063.0/2097152.0,14559064751.0/4194304.0,-15766137527.0/8388608.0,3774819027.0/4194304.0,-1588096377.0/4194304.0,582044911.0/4194304.0,-367619987.0/8388608.0,49300931.0/4194304.0,-5507631.0/2097152.0,498871.0/1048576.0,-35209.0/524288.0,1817.0/262144.0,-61.0/131072.0,1.0/65536.0};
	res_derK=Herm2DerK(p_val,n_derK,x_val,k);
	gettimeofday(&et,NULL);
	elapsed = ((et.tv_sec - st.tv_sec) * 1000000) + (et.tv_usec - st.tv_usec);
	printf("Herm2Derk time: %d micro seconds\n",elapsed);	
 	printf("the result of Herm2DerK is %14.14e\n",res_derK);
 	
 	
}
int main(void)
{
 	/*struct timeval st, et;
 	double res;
	gettimeofday(&st,NULL);
	double x=0.65;
 	int n=17;
 	double p[]={-28471492267.0/4194304.0,26980769367.0/2097152.0,-45904273683.0/4194304.0,17507317561.0/2097152.0,-11950694063.0/2097152.0,14559064751.0/4194304.0,-15766137527.0/8388608.0,3774819027.0/4194304.0,-1588096377.0/4194304.0,582044911.0/4194304.0,-367619987.0/8388608.0,49300931.0/4194304.0,-5507631.0/2097152.0,498871.0/1048576.0,-35209.0/524288.0,1817.0/262144.0,-61.0/131072.0,1.0/65536.0};
	int i=0;
	res+=Herm2DerK(p,n,x,4);
	
	gettimeofday(&et,NULL);
	int elapsed = ((et.tv_sec - st.tv_sec) * 1000000) + (et.tv_usec - st.tv_usec);
	printf("Sorting time: %d micro seconds\n",elapsed);	
	
	
 	 printf("the result of Herm2DerK is %14.14e\n",res);
*/
	struct timeval st, et;
	gettimeofday(&st,NULL);
	int i=0;
	for(i=0;i<100;i++){
	//printf("herm2---------------------------------------------------------------------------\n");
		herm2();
	}
	gettimeofday(&et,NULL);
	int elapsed = ((et.tv_sec - st.tv_sec) * 1000000) + (et.tv_usec - st.tv_usec);
	//printf("herm2---------------------------------------------------------------------------\n");
	//herm2();
	 printf("cheb1 time: %d micro seconds\n",elapsed);
}
