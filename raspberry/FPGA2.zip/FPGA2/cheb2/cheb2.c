#include<stdio.h>
#include<assert.h>
#include<stdlib.h>
#include<math.h>
#include<sys/time.h>

/*Cheb2Val evaluates a series of Chebyshev polynomial of the second kind at the point x, which is in [-1, 1]. */
double Cheb2Val(double *P, unsigned int n, double x)
{
    assert ( 0 < n);
    assert (fabs(x)<=1.0);
    double  xx,t,b1=0,b2=0;
    int i;
    xx=2*x;

    for(i=n; i>=1; i--) 
    {
        t=xx*b1-b2+P[i];
        b2=b1;
        b1=t;
    }
    return 2*x*b1-b2+P[0];
}
/*Cheb2Der evaluates  the first  derivative of a series of Chebyshev polynomial of the second kind at the point x, which is in [-1, 1]. */
double Cheb2Der(double *P, unsigned int n, double x)
{
    assert ( 0 < n);
    assert (fabs(x)<=1.0);
    double  t,b1=0,b2=0;
    double  A1,A2;
    int i;
    double C;
    C=2;

    for(i=n-1; i>=0; i--) 
    {
        A1=(2*i+4)*x/(i+1);
        A2=-1.0*(i+4)/(i+2);
        t=A1*b1+A2*b2+P[i+1];
        b2=b1;
        b1=t;
    }
    return  C*b1;
}

/*Cheb2DerK evaluates  the k-th  derivative of a series of Chebyshev polynomial of the second kind at the point x, which is in [-1, 1]. */
double Cheb2DerK(double *P, unsigned int n, double x, unsigned int k)
{
    assert ( 0 < n);
    assert (fabs(x)<=1.0);
    double  t,b1=0,b2=0;
    int i;
    double s=1.0,j;
    for(i=k;i>0;i--)
    {
       s=2*s*i;
    }

    for(i=n-k; i>=0; i--) 
    {
        j=1.0*i;
        t=2*(j+k+1)/(j+1)*x*b1-(j+2*k+2)/(j+2)*b2+P[i+k];
        b2=b1;
        b1=t;
    }
    return  s*b1;
}


void cheb2(){
	struct timeval st, et;
	int elapsed;
 	//Val
	double res_val;
	gettimeofday(&st,NULL);
	double x_val=0.65;
 	int n_val=17;
 	double p_val[]={-1315.91687810420989990234375,2258.646918773651123046875,-2622.94835531711578369140625,2438.49401128292083740234375,-1909.532471001148223876953125,1285.582271099090576171875,-750.419185936450958251953125,380.608334064483642578125,-167.403982102870941162109375,63.508031368255615234375,-20.598737180233001708984375,5.63924872875213623046875,-1.2795436382293701171875,0.234414577484130859375,-0.03334522247314453125,0.0034580230712890625,-0.000232696533203125,0.00000762939453125};
	res_val=Cheb2Val(p_val,n_val,x_val);
	gettimeofday(&et,NULL);
	elapsed = ((et.tv_sec - st.tv_sec) * 1000000) + (et.tv_usec - st.tv_usec);
	printf("Cheb2Val time: %d micro seconds\n",elapsed);	
 	printf("the result of Cheb2Val is %14.14e\n",res_val);
 	//Der
	double res_der;
	gettimeofday(&st,NULL);
	double x_der=0.65;
 	int n_der=17;
 	double p_der[]={-1315.91687810420989990234375,2258.646918773651123046875,-2622.94835531711578369140625,2438.49401128292083740234375,-1909.532471001148223876953125,1285.582271099090576171875,-750.419185936450958251953125,380.608334064483642578125,-167.403982102870941162109375,63.508031368255615234375,-20.598737180233001708984375,5.63924872875213623046875,-1.2795436382293701171875,0.234414577484130859375,-0.03334522247314453125,0.0034580230712890625,-0.000232696533203125,0.00000762939453125};
	res_der=Cheb2Der(p_der,n_der,x_der);
	gettimeofday(&et,NULL);
	elapsed = ((et.tv_sec - st.tv_sec) * 1000000) + (et.tv_usec - st.tv_usec);
	printf("Cheb2Der time: %d micro seconds\n",elapsed);	
 	printf("the result of Cheb2Der is %14.14e\n",res_der);
 	//DerK
 	double res_derK;
	gettimeofday(&st,NULL);
	double x_derK=0.65;
 	int n_derK=17;
 	int k=4;
 	double p_derK[]={-1315.91687810420989990234375,2258.646918773651123046875,-2622.94835531711578369140625,2438.49401128292083740234375,-1909.532471001148223876953125,1285.582271099090576171875,-750.419185936450958251953125,380.608334064483642578125,-167.403982102870941162109375,63.508031368255615234375,-20.598737180233001708984375,5.63924872875213623046875,-1.2795436382293701171875,0.234414577484130859375,-0.03334522247314453125,0.0034580230712890625,-0.000232696533203125,0.00000762939453125};
	res_derK=Cheb2DerK(p_val,n_derK,x_val,k);
	gettimeofday(&et,NULL);
	elapsed = ((et.tv_sec - st.tv_sec) * 1000000) + (et.tv_usec - st.tv_usec);
	printf("Cheb2DerK time: %d micro seconds\n",elapsed);	
 	printf("the result of Cheb2DerK is %14.14e\n",res_derK);
 	
 	
}
int main(void)
{
 	/*struct timeval st, et;
 	double res;
	gettimeofday(&st,NULL);
	double x=0.65;
 	int n=17;
 	double p[]={-28471492267.0/4194304.0,26980769367.0/2097152.0,-45904273683.0/4194304.0,17507317561.0/2097152.0,-11950694063.0/2097152.0,14559064751.0/4194304.0,-15766137527.0/8388608.0,3774819027.0/4194304.0,-1588096377.0/4194304.0,582044911.0/4194304.0,-367619987.0/8388608.0,49300931.0/4194304.0,-5507631.0/2097152.0,498871.0/1048576.0,-35209.0/524288.0,1817.0/262144.0,-61.0/131072.0,1.0/65536.0};
	int i=0;
	res+=Herm2DerK(p,n,x,4);
	
	gettimeofday(&et,NULL);
	int elapsed = ((et.tv_sec - st.tv_sec) * 1000000) + (et.tv_usec - st.tv_usec);
	printf("Sorting time: %d micro seconds\n",elapsed);	
	
	
 	 printf("the result of Herm2DerK is %14.14e\n",res);
*/
	struct timeval st, et;
	gettimeofday(&st,NULL);
	int i=0;
	for(i=0;i<100;i++){
	//printf("cheb2---------------------------------------------------------------------------\n");
		cheb2();
	}
	gettimeofday(&et,NULL);
	int elapsed = ((et.tv_sec - st.tv_sec) * 1000000) + (et.tv_usec - st.tv_usec);
	//printf("cheb2---------------------------------------------------------------------------\n");
	//cheb2();
	 printf("cheb1 time: %d micro seconds\n",elapsed);
}
