// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2019.1 (64-bit)
// Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
// ==============================================================
/***************************** Include Files *********************************/
#include "xherm2.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XHerm2_CfgInitialize(XHerm2 *InstancePtr, XHerm2_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Crtl_bus_BaseAddress = ConfigPtr->Crtl_bus_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XHerm2_Start(XHerm2 *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XHerm2_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XHERM2_CRTL_BUS_ADDR_AP_CTRL) & 0x80;
    XHerm2_WriteReg(InstancePtr->Crtl_bus_BaseAddress, XHERM2_CRTL_BUS_ADDR_AP_CTRL, Data | 0x01);
}

u32 XHerm2_IsDone(XHerm2 *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XHerm2_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XHERM2_CRTL_BUS_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XHerm2_IsIdle(XHerm2 *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XHerm2_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XHERM2_CRTL_BUS_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XHerm2_IsReady(XHerm2 *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XHerm2_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XHERM2_CRTL_BUS_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XHerm2_EnableAutoRestart(XHerm2 *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XHerm2_WriteReg(InstancePtr->Crtl_bus_BaseAddress, XHERM2_CRTL_BUS_ADDR_AP_CTRL, 0x80);
}

void XHerm2_DisableAutoRestart(XHerm2 *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XHerm2_WriteReg(InstancePtr->Crtl_bus_BaseAddress, XHERM2_CRTL_BUS_ADDR_AP_CTRL, 0);
}

u32 XHerm2_Get_return(XHerm2 *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XHerm2_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XHERM2_CRTL_BUS_ADDR_AP_RETURN);
    return Data;
}
void XHerm2_Set_op(XHerm2 *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XHerm2_WriteReg(InstancePtr->Crtl_bus_BaseAddress, XHERM2_CRTL_BUS_ADDR_OP_DATA, Data);
}

u32 XHerm2_Get_op(XHerm2 *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XHerm2_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XHERM2_CRTL_BUS_ADDR_OP_DATA);
    return Data;
}

void XHerm2_Set_size(XHerm2 *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XHerm2_WriteReg(InstancePtr->Crtl_bus_BaseAddress, XHERM2_CRTL_BUS_ADDR_SIZE_DATA, Data);
}

u32 XHerm2_Get_size(XHerm2 *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XHerm2_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XHERM2_CRTL_BUS_ADDR_SIZE_DATA);
    return Data;
}

void XHerm2_InterruptGlobalEnable(XHerm2 *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XHerm2_WriteReg(InstancePtr->Crtl_bus_BaseAddress, XHERM2_CRTL_BUS_ADDR_GIE, 1);
}

void XHerm2_InterruptGlobalDisable(XHerm2 *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XHerm2_WriteReg(InstancePtr->Crtl_bus_BaseAddress, XHERM2_CRTL_BUS_ADDR_GIE, 0);
}

void XHerm2_InterruptEnable(XHerm2 *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XHerm2_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XHERM2_CRTL_BUS_ADDR_IER);
    XHerm2_WriteReg(InstancePtr->Crtl_bus_BaseAddress, XHERM2_CRTL_BUS_ADDR_IER, Register | Mask);
}

void XHerm2_InterruptDisable(XHerm2 *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XHerm2_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XHERM2_CRTL_BUS_ADDR_IER);
    XHerm2_WriteReg(InstancePtr->Crtl_bus_BaseAddress, XHERM2_CRTL_BUS_ADDR_IER, Register & (~Mask));
}

void XHerm2_InterruptClear(XHerm2 *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XHerm2_WriteReg(InstancePtr->Crtl_bus_BaseAddress, XHERM2_CRTL_BUS_ADDR_ISR, Mask);
}

u32 XHerm2_InterruptGetEnabled(XHerm2 *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XHerm2_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XHERM2_CRTL_BUS_ADDR_IER);
}

u32 XHerm2_InterruptGetStatus(XHerm2 *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XHerm2_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XHERM2_CRTL_BUS_ADDR_ISR);
}

