// ==============================================================
// File generated on Mon Aug 12 15:01:44 +0430 2019
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2018.3 (64-bit)
// SW Build 2405991 on Thu Dec  6 23:38:27 MST 2018
// IP Build 2404404 on Fri Dec  7 01:43:56 MST 2018
// Copyright 1986-2018 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef XHERM2_H
#define XHERM2_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xherm2_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
#else
typedef struct {
    u16 DeviceId;
    u32 Crtl_bus_BaseAddress;
} XHerm2_Config;
#endif

typedef struct {
    u32 Crtl_bus_BaseAddress;
    u32 IsReady;
} XHerm2;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XHerm2_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XHerm2_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XHerm2_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XHerm2_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
int XHerm2_Initialize(XHerm2 *InstancePtr, u16 DeviceId);
XHerm2_Config* XHerm2_LookupConfig(u16 DeviceId);
int XHerm2_CfgInitialize(XHerm2 *InstancePtr, XHerm2_Config *ConfigPtr);
#else
int XHerm2_Initialize(XHerm2 *InstancePtr, const char* InstanceName);
int XHerm2_Release(XHerm2 *InstancePtr);
#endif

void XHerm2_Start(XHerm2 *InstancePtr);
u32 XHerm2_IsDone(XHerm2 *InstancePtr);
u32 XHerm2_IsIdle(XHerm2 *InstancePtr);
u32 XHerm2_IsReady(XHerm2 *InstancePtr);
void XHerm2_EnableAutoRestart(XHerm2 *InstancePtr);
void XHerm2_DisableAutoRestart(XHerm2 *InstancePtr);
u32 XHerm2_Get_return(XHerm2 *InstancePtr);

void XHerm2_Set_op(XHerm2 *InstancePtr, u32 Data);
u32 XHerm2_Get_op(XHerm2 *InstancePtr);
void XHerm2_Set_size(XHerm2 *InstancePtr, u32 Data);
u32 XHerm2_Get_size(XHerm2 *InstancePtr);

void XHerm2_InterruptGlobalEnable(XHerm2 *InstancePtr);
void XHerm2_InterruptGlobalDisable(XHerm2 *InstancePtr);
void XHerm2_InterruptEnable(XHerm2 *InstancePtr, u32 Mask);
void XHerm2_InterruptDisable(XHerm2 *InstancePtr, u32 Mask);
void XHerm2_InterruptClear(XHerm2 *InstancePtr, u32 Mask);
u32 XHerm2_InterruptGetEnabled(XHerm2 *InstancePtr);
u32 XHerm2_InterruptGetStatus(XHerm2 *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
