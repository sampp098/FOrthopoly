#include <hls_stream.h>
#include <ap_axi_sdata.h>
#include <hls_math.h>
#define max_P_size 200

double P[max_P_size];
double X[max_P_size];
double B[max_P_size];


int Herm2(int op, int size,double inx[max_P_size],double inp[max_P_size],double out[max_P_size*3]){

#pragma HLS INTERFACE s_axilite port=op		bundle=CRTL_BUS
#pragma HLS INTERFACE s_axilite port=size bundle=CRTL_BUS
#pragma HLS INTERFACE bram port=inx
#pragma HLS INTERFACE bram port=inp
#pragma HLS INTERFACE bram port=out
#pragma HLS INTERFACE s_axilite port=return bundle=CRTL_BUS

	if (op == 0) { //read P
		P[0] = size;
		for (int i = 0; i < size; i++) {
			P[i+1] = inp[i];
		}
	} else if (op == 1) { // read X
		X[0] = size;
		X[1] = inx[0];//k
		for (int i = 1; i < size+1; i++) {
			X[i+1] = inx[i];
		}
	}  else if (op == 2) { // check X
		for (int i = 0; i <= size; i++) {
			inx[i] = X[i];
		}
	}  else if (op == 3) { // check P
		for (int i = 0; i <= size; i++) {
			inp[i] = P[i];
		}
	} else if (op == 4) {

		int p_size = (int) P[0];
		int x_size = (int) X[0];
		int k = (int) X[1];

		int res = 0;
		int l=x_size + 2;

		//hermit2 Pre calc
		double  C_derk=1.0;
		#pragma HLS PIPELINE
			for(int i=k;i>0;i--)
			{
				C_derk=2*C_derk;
			}

		for (int i_x = 2; i_x < l; i_x++, res += 3) {
			//if ((i_x)<l ) {
				double x = X[i_x];
				//init
				//hermit2Val
				double  xx,t_val,b1_val=0,b2_val=0;
				xx=2*x;
				//hermit2Der
				double  t_der,b1_der=0,b2_der=0;
				//hermit2DerK
				double s_derk,t_derk,b1_derk=0,b2_derk=0;


				for(int i =0; i<p_size; i++){
					int ii=p_size-1-i;
					//hermit2Val
					#pragma HLS PIPELINE
					{
						t_val=xx*b1_val-2*(ii+1)*b2_val+P[i];
						b2_val=b1_val;
						b1_val=t_val;
					}

					//hermit2Der
					#pragma HLS PIPELINE
					{
						if(i>0){

							t_der=xx*b1_der-2*(ii+1)*b2_der+2*(ii+1)*P[i-1];
							b2_der=b1_der;
							b1_der=t_der;

						}
					}
					//hermit2DerK
					#pragma HLS PIPELINE
						if(i>=k){
							s_derk=1.0;
							for(int j=ii+k;j>=ii+1;j--){
								s_derk=s_derk*j;
							}
							t_derk=xx*b1_derk-2*(ii+1)*b2_derk+s_derk*P[i-k];

							b2_derk=b1_derk;
							b1_derk=t_derk;

						}
				}
				//hermit2Val =
				out[res] = b1_val;

				//hermit2Der
				out[res + 1] = b1_der;
				//cheb2Val=2*chebVal;

				//hermit2DerK =
				out[res + 2] = C_derk*b1_derk;

			/*}
			if ((i_x+1)<l ) {
				double x = X[i_x+1];
				//init
				//hermit2Val
				double  xx,t_val,b1_val=0,b2_val=0;
				xx=2*x;
				//hermit2Der
				double  t_der,b1_der=0,b2_der=0;
				//hermit2DerK
				double s_derk,t_derk,b1_derk=0,b2_derk=0;


				for(int i =0; i<p_size; i++){
					int ii=p_size-1-i;
					//hermit2Val
					#pragma HLS PIPELINE
					{
						t_val=xx*b1_val-2*(ii+1)*b2_val+P[i];
						b2_val=b1_val;
						b1_val=t_val;
					}

					//hermit2Der
					#pragma HLS PIPELINE
					{
						if(i>0){

							t_der=xx*b1_der-2*(ii+1)*b2_der+2*(ii+1)*P[i-1];
							b2_der=b1_der;
							b1_der=t_der;

						}
					}
					//hermit2DerK
					#pragma HLS PIPELINE
						if(i>=k){
							s_derk=1.0;
							for(int j=ii+k;j>=ii+1;j--){
								s_derk=s_derk*j;
							}
							t_derk=xx*b1_derk-2*(ii+1)*b2_derk+s_derk*P[i-k];

							b2_derk=b1_derk;
							b1_derk=t_derk;

						}
				}
				//hermit2Val =
				out[res+3] = b1_val;

				//hermit2Der
				out[res + 4] = b1_der;
				//cheb2Val=2*chebVal;

				//hermit2DerK =
				out[res + 5] = C_derk*b1_derk;
			}*/
		}
	}
	return 0;
}
