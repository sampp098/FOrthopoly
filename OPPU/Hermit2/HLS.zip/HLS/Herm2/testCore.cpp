#include <stdio.h>
#include <hls_stream.h>
#include <ap_axi_sdata.h>

typedef ap_axis<64,2,5,6> intSdCh;

int cheb2(double &chebVal,double &cheb1Der,double &cheb1DerK,unsigned int p_size1,unsigned int k, double x, hls::stream<intSdCh> &inStream);

uint64_t double_to_u64(double val);
double u64_to_double(uint64_t val);
int main(){

	hls::stream<intSdCh> inputStream;
	//hls::stream<intSdCh> outputStream;
	double p[]={-28471492267.0,4194304.0,26980769367.0,2097152.0,-45904273683.0,4194304.0,17507317561.0,2097152.0,-11950694063.0,2097152.0,14559064751.0,4194304.0,-15766137527.0,8388608.0,3774819027.0,4194304.0,-1588096377.0,4194304.0,582044911.0,4194304.0,-367619987.0,8388608.0,49300931.0,4194304.0,-5507631.0,2097152.0,498871.0,1048576.0,-35209.0,524288.0,1817.0,262144.0,-61.0,131072.0,1.0,65536.0};
	//double p[]={-28471492267.0/4194304.0,26980769367.0/2097152.0,-45904273683.0/4194304.0,17507317561.0/2097152.0,-11950694063.0/2097152.0,14559064751.0/4194304.0,-15766137527.0/8388608.0,3774819027.0/4194304.0,-1588096377.0/4194304.0,582044911.0/4194304.0,-367619987.0/8388608.0,49300931.0/4194304.0,-5507631.0/2097152.0,498871.0/1048576.0,-35209.0/524288.0,1817.0/262144.0,-61.0/131072.0,1.0/65536.0};
	//double x=0.65;
	//int p_size=18;


	//double p[]={-28471492267.0,4194304.0,26980769367.0,2097152.0};
	double x=0.65;
	unsigned int p_size=18;

	for(int idx =(p_size*2)-1; idx>=0; idx--){
		intSdCh valIn1;

		valIn1.data = double_to_u64(p[idx]);
		valIn1.keep = 1;
		valIn1.strb = 1;
		valIn1.user = 1;
		valIn1.id   = 0;
		valIn1.dest = 0;

		inputStream << valIn1;
	}

	double chebVal,cheb1Der,cheb1DerK;
	int k=4;
	int e=cheb(chebVal,cheb1Der,cheb1DerK, p_size,k, x, inputStream);
	printf("the result of Cheb1Val is %14.14e\n cheb1Der is  %14.14e\n cheb1DerK is  %14.14e\n and return=%d\n", chebVal,cheb1Der,cheb1DerK, e);

	/*for(int idxOut =0; idxOut<p_size*2; idxOut++){
		intSdCh valOut1;
		outputStream.read(valOut1);

		printf("Value is %14.14e\n", u64_to_double(valOut1.data));
	}*/

	return 0;
}
