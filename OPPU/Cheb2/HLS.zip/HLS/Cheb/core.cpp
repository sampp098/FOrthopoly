#include <hls_stream.h>
#include <ap_axi_sdata.h>
#include <hls_math.h>
#define max_P_size 200

double P[max_P_size];
double X[max_P_size];
double B[max_P_size];
double tmp_DerK_1[max_P_size];
double tmp_DerK_2[max_P_size];

int cheb2(int op, int size,double inx[max_P_size],double inp[max_P_size],double out[max_P_size*3]){

#pragma HLS INTERFACE s_axilite port=op		bundle=CRTL_BUS
#pragma HLS INTERFACE s_axilite port=size bundle=CRTL_BUS
#pragma HLS INTERFACE bram port=inx
#pragma HLS INTERFACE bram port=inp
#pragma HLS INTERFACE bram port=out
#pragma HLS INTERFACE s_axilite port=return bundle=CRTL_BUS

	if (op == 0) { //read P
		P[0] = size;
		for (int i = 0; i < size; i++) {
			P[i+1] = inp[i];
		}
	} else if (op == 1) { // read X
		X[0] = size;
		X[1] = inx[0];//k
		for (int i = 1; i < size+1; i++) {
			X[i+1] = inx[i];
		}
	}  else if (op == 2) { // check X
		for (int i = 0; i <= size; i++) {
			inx[i] = X[i];
		}
	}  else if (op == 3) { // check P
		for (int i = 0; i <= size; i++) {
			inp[i] = P[i];
		}
	} else if (op == 4) {

		int p_size = (int) P[0];
		int x_size = (int) X[0];
		int k = (int) X[1];

		int res = 0;
		int l=x_size + 2;
		for (int i_x = 2; i_x < l; i_x++, res += 3) {
			//if ((i_x)<l ) {
				double x = X[i_x];
				//init
				double  t_Val,b1_Val=0,b2_Val=0;
				double xx = 2 * x;

				//cheb2Der
				double  t_Der,b1_Der=0,b2_Der=0;
				double  A1_Der,A2_Der;
				//cheb2DerK
				double  t_DerK,b1_DerK=0,b2_DerK=0;
				double s_DerK=1.0,j_DerK;

				if (!(0 < p_size - 1)) {
					return 1;
				}
				if (!(hls::fabs(x) <= 1.0)) {
					return 2;
				}


				for (int i = 0; i < p_size - 1; i++) {
					int ii=p_size-1-i;
					//cheb2Val
					#pragma HLS PIPELINE
					{
						if(i<p_size-1){
							t_Val=xx*b1_Val-b2_Val+P[i+1];
							b2_Val=b1_Val;
							b1_Val=t_Val;
						}else{
							b1_Val=xx*b1_Val-b2_Val+P[i+1];
						}
					}
					//cheb2Der
					//#pragma HLS PIPELINE
					{
						if(i>1){
							A1_Der=(2*(ii)+4)*x/((ii)+1);
							A2_Der=-1.0*((ii)+4)/((ii)+2);
							t_Der=A1_Der*b1_Der+A2_Der*b2_Der+P[i];
							b2_Der=b1_Der;
							b1_Der=t_Der;
						}
					}
					//cheb2DerK
					//#pragma HLS PIPELINE
					if(i<k && i>=0){
						s_DerK=2*s_DerK*(i+1);
					}else if(i>=k){
						j_DerK=ii;//j_DerK=1.0*ii;
						if(i_x==2){
							tmp_DerK_1[i]=2*(j_DerK+k+1)/(j_DerK+1);
							tmp_DerK_2[i]=(j_DerK+2*k+2)/(j_DerK+2);
						}
						t_DerK=tmp_DerK_1[i]*x*b1_DerK-tmp_DerK_2[i]*b2_DerK+P[i-k+1];
						b2_DerK=b1_DerK;
						b1_DerK=t_DerK;
					}
				}
				//cheb1Der
				out[res] = b1_Val;;

				//chebVal =
				out[res + 1] = 2*b1_Der;
				//cheb2Val=2*chebVal;

				//cheb1DerK =
				out[res + 2] = s_DerK*b1_DerK;

		}
	}
	return 0;
}
