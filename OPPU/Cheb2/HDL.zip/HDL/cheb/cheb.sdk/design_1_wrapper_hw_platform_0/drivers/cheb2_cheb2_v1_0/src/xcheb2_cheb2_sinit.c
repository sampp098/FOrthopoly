// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2019.1 (64-bit)
// Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#include "xparameters.h"
#include "xcheb2_cheb2.h"

extern XCheb2_cheb2_Config XCheb2_cheb2_ConfigTable[];

XCheb2_cheb2_Config *XCheb2_cheb2_LookupConfig(u16 DeviceId) {
	XCheb2_cheb2_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XCHEB2_CHEB2_NUM_INSTANCES; Index++) {
		if (XCheb2_cheb2_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XCheb2_cheb2_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XCheb2_cheb2_Initialize(XCheb2_cheb2 *InstancePtr, u16 DeviceId) {
	XCheb2_cheb2_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XCheb2_cheb2_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XCheb2_cheb2_CfgInitialize(InstancePtr, ConfigPtr);
}

#endif

