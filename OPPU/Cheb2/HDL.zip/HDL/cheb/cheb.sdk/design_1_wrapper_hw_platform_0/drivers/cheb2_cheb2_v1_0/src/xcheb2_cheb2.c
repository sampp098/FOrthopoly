// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2019.1 (64-bit)
// Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
// ==============================================================
/***************************** Include Files *********************************/
#include "xcheb2_cheb2.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XCheb2_cheb2_CfgInitialize(XCheb2_cheb2 *InstancePtr, XCheb2_cheb2_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Crtl_bus_BaseAddress = ConfigPtr->Crtl_bus_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XCheb2_cheb2_Start(XCheb2_cheb2 *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCheb2_cheb2_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XCHEB2_CHEB2_CRTL_BUS_ADDR_AP_CTRL) & 0x80;
    XCheb2_cheb2_WriteReg(InstancePtr->Crtl_bus_BaseAddress, XCHEB2_CHEB2_CRTL_BUS_ADDR_AP_CTRL, Data | 0x01);
}

u32 XCheb2_cheb2_IsDone(XCheb2_cheb2 *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCheb2_cheb2_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XCHEB2_CHEB2_CRTL_BUS_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XCheb2_cheb2_IsIdle(XCheb2_cheb2 *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCheb2_cheb2_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XCHEB2_CHEB2_CRTL_BUS_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XCheb2_cheb2_IsReady(XCheb2_cheb2 *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCheb2_cheb2_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XCHEB2_CHEB2_CRTL_BUS_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XCheb2_cheb2_EnableAutoRestart(XCheb2_cheb2 *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XCheb2_cheb2_WriteReg(InstancePtr->Crtl_bus_BaseAddress, XCHEB2_CHEB2_CRTL_BUS_ADDR_AP_CTRL, 0x80);
}

void XCheb2_cheb2_DisableAutoRestart(XCheb2_cheb2 *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XCheb2_cheb2_WriteReg(InstancePtr->Crtl_bus_BaseAddress, XCHEB2_CHEB2_CRTL_BUS_ADDR_AP_CTRL, 0);
}

u32 XCheb2_cheb2_Get_return(XCheb2_cheb2 *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCheb2_cheb2_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XCHEB2_CHEB2_CRTL_BUS_ADDR_AP_RETURN);
    return Data;
}
void XCheb2_cheb2_Set_op(XCheb2_cheb2 *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XCheb2_cheb2_WriteReg(InstancePtr->Crtl_bus_BaseAddress, XCHEB2_CHEB2_CRTL_BUS_ADDR_OP_DATA, Data);
}

u32 XCheb2_cheb2_Get_op(XCheb2_cheb2 *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCheb2_cheb2_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XCHEB2_CHEB2_CRTL_BUS_ADDR_OP_DATA);
    return Data;
}

void XCheb2_cheb2_Set_size(XCheb2_cheb2 *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XCheb2_cheb2_WriteReg(InstancePtr->Crtl_bus_BaseAddress, XCHEB2_CHEB2_CRTL_BUS_ADDR_SIZE_DATA, Data);
}

u32 XCheb2_cheb2_Get_size(XCheb2_cheb2 *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCheb2_cheb2_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XCHEB2_CHEB2_CRTL_BUS_ADDR_SIZE_DATA);
    return Data;
}

void XCheb2_cheb2_InterruptGlobalEnable(XCheb2_cheb2 *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XCheb2_cheb2_WriteReg(InstancePtr->Crtl_bus_BaseAddress, XCHEB2_CHEB2_CRTL_BUS_ADDR_GIE, 1);
}

void XCheb2_cheb2_InterruptGlobalDisable(XCheb2_cheb2 *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XCheb2_cheb2_WriteReg(InstancePtr->Crtl_bus_BaseAddress, XCHEB2_CHEB2_CRTL_BUS_ADDR_GIE, 0);
}

void XCheb2_cheb2_InterruptEnable(XCheb2_cheb2 *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XCheb2_cheb2_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XCHEB2_CHEB2_CRTL_BUS_ADDR_IER);
    XCheb2_cheb2_WriteReg(InstancePtr->Crtl_bus_BaseAddress, XCHEB2_CHEB2_CRTL_BUS_ADDR_IER, Register | Mask);
}

void XCheb2_cheb2_InterruptDisable(XCheb2_cheb2 *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XCheb2_cheb2_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XCHEB2_CHEB2_CRTL_BUS_ADDR_IER);
    XCheb2_cheb2_WriteReg(InstancePtr->Crtl_bus_BaseAddress, XCHEB2_CHEB2_CRTL_BUS_ADDR_IER, Register & (~Mask));
}

void XCheb2_cheb2_InterruptClear(XCheb2_cheb2 *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XCheb2_cheb2_WriteReg(InstancePtr->Crtl_bus_BaseAddress, XCHEB2_CHEB2_CRTL_BUS_ADDR_ISR, Mask);
}

u32 XCheb2_cheb2_InterruptGetEnabled(XCheb2_cheb2 *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XCheb2_cheb2_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XCHEB2_CHEB2_CRTL_BUS_ADDR_IER);
}

u32 XCheb2_cheb2_InterruptGetStatus(XCheb2_cheb2 *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XCheb2_cheb2_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XCHEB2_CHEB2_CRTL_BUS_ADDR_ISR);
}

