// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2019.1 (64-bit)
// Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
// ==============================================================
/***************************** Include Files *********************************/
#include "xherm1.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XHerm1_CfgInitialize(XHerm1 *InstancePtr, XHerm1_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Crtl_bus_BaseAddress = ConfigPtr->Crtl_bus_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XHerm1_Start(XHerm1 *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XHerm1_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XHERM1_CRTL_BUS_ADDR_AP_CTRL) & 0x80;
    XHerm1_WriteReg(InstancePtr->Crtl_bus_BaseAddress, XHERM1_CRTL_BUS_ADDR_AP_CTRL, Data | 0x01);
}

u32 XHerm1_IsDone(XHerm1 *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XHerm1_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XHERM1_CRTL_BUS_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XHerm1_IsIdle(XHerm1 *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XHerm1_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XHERM1_CRTL_BUS_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XHerm1_IsReady(XHerm1 *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XHerm1_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XHERM1_CRTL_BUS_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XHerm1_EnableAutoRestart(XHerm1 *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XHerm1_WriteReg(InstancePtr->Crtl_bus_BaseAddress, XHERM1_CRTL_BUS_ADDR_AP_CTRL, 0x80);
}

void XHerm1_DisableAutoRestart(XHerm1 *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XHerm1_WriteReg(InstancePtr->Crtl_bus_BaseAddress, XHERM1_CRTL_BUS_ADDR_AP_CTRL, 0);
}

u32 XHerm1_Get_return(XHerm1 *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XHerm1_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XHERM1_CRTL_BUS_ADDR_AP_RETURN);
    return Data;
}
void XHerm1_Set_op(XHerm1 *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XHerm1_WriteReg(InstancePtr->Crtl_bus_BaseAddress, XHERM1_CRTL_BUS_ADDR_OP_DATA, Data);
}

u32 XHerm1_Get_op(XHerm1 *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XHerm1_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XHERM1_CRTL_BUS_ADDR_OP_DATA);
    return Data;
}

void XHerm1_Set_size(XHerm1 *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XHerm1_WriteReg(InstancePtr->Crtl_bus_BaseAddress, XHERM1_CRTL_BUS_ADDR_SIZE_DATA, Data);
}

u32 XHerm1_Get_size(XHerm1 *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XHerm1_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XHERM1_CRTL_BUS_ADDR_SIZE_DATA);
    return Data;
}

void XHerm1_InterruptGlobalEnable(XHerm1 *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XHerm1_WriteReg(InstancePtr->Crtl_bus_BaseAddress, XHERM1_CRTL_BUS_ADDR_GIE, 1);
}

void XHerm1_InterruptGlobalDisable(XHerm1 *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XHerm1_WriteReg(InstancePtr->Crtl_bus_BaseAddress, XHERM1_CRTL_BUS_ADDR_GIE, 0);
}

void XHerm1_InterruptEnable(XHerm1 *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XHerm1_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XHERM1_CRTL_BUS_ADDR_IER);
    XHerm1_WriteReg(InstancePtr->Crtl_bus_BaseAddress, XHERM1_CRTL_BUS_ADDR_IER, Register | Mask);
}

void XHerm1_InterruptDisable(XHerm1 *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XHerm1_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XHERM1_CRTL_BUS_ADDR_IER);
    XHerm1_WriteReg(InstancePtr->Crtl_bus_BaseAddress, XHERM1_CRTL_BUS_ADDR_IER, Register & (~Mask));
}

void XHerm1_InterruptClear(XHerm1 *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XHerm1_WriteReg(InstancePtr->Crtl_bus_BaseAddress, XHERM1_CRTL_BUS_ADDR_ISR, Mask);
}

u32 XHerm1_InterruptGetEnabled(XHerm1 *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XHerm1_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XHERM1_CRTL_BUS_ADDR_IER);
}

u32 XHerm1_InterruptGetStatus(XHerm1 *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XHerm1_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XHERM1_CRTL_BUS_ADDR_ISR);
}

