#include <stdio.h>
#include <hls_stream.h>
//#include "core.h"

typedef uint32_t u32;
#define max_P_size 200

int Gegen(int op, int size,double* inx,double* inp,double* out);

void test(){
	double P_Data[max_P_size];
	double p[]=  {-28471492267.0/4194304.0,26980769367.0/2097152.0,-45904273683.0/4194304.0,17507317561.0/2097152.0,-11950694063.0/2097152.0,14559064751.0/4194304.0,-15766137527.0/8388608.0,3774819027.0/4194304.0,-1588096377.0/4194304.0,582044911.0/4194304.0,-367619987.0/8388608.0,49300931.0/4194304.0,-5507631.0/2097152.0,498871.0/1048576.0,-35209.0/524288.0,1817.0/262144.0,-61.0/131072.0,1.0/65536.0};
	u32 p_size = 18;
	int idx = 0;
	for (int i = p_size - 1; i >= 0; i--) {
		//P_Data[idx++] = i+2;
		P_Data[idx++]=p[i];
	}

	double X_Data[max_P_size];
	double x = 0.65;
	int x_size=100;
	X_Data[0]= 4;//k
	X_Data[1]= 1.0;//lambda
	for(int i=2;i<x_size+2;i++){
		X_Data[i]= x;
	}

	int size=100;
	double results[max_P_size*3];

	Gegen(0,p_size,X_Data,P_Data,results);
	Gegen(1,x_size,X_Data,P_Data,results);
	Gegen(4,size,X_Data,P_Data,results);
	int res=0;
	for(int i=0;i<size;i++){
		printf("---------------------\nval[%d]: %14.14e\n",i,results[res++]);
		printf("der[%d]: %14.14e\n",i,results[res++]);
		printf("derk[%d]: %14.14e\n",i,results[res++]);
	}
}

int main(){

	test();
	return 0;
}
