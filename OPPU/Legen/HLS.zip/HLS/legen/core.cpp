#include <hls_stream.h>
#include <ap_axi_sdata.h>
#include <hls_math.h>
//#include <stdio.h>
#define max_P_size 200

double P[max_P_size];
double X[max_P_size];

int legen(int op, int size,double inx[max_P_size],double inp[max_P_size],double out[max_P_size*3]){
#pragma HLS INTERFACE s_axilite port=op		bundle=CRTL_BUS
#pragma HLS INTERFACE s_axilite port=size bundle=CRTL_BUS
#pragma HLS INTERFACE bram port=inx
#pragma HLS INTERFACE bram port=inp
#pragma HLS INTERFACE bram port=out
#pragma HLS INTERFACE s_axilite port=return bundle=CRTL_BUS

	if (op == 0) { //read P
		P[0] = size;
		for (int i = 0; i < size; i++) {
			P[i+1] = inp[i];
		}
	} else if (op == 1) { // read X
		X[0] = size;
		X[1] = inx[0];//k
		X[2] = inx[1];//alpha
		X[3] = inx[2];//beta
		for (int i = 3; i < size+3; i++) {
			X[i+1] = inx[i];
		}
	}  else if (op == 2) { // check X
		for (int i = 0; i <= size; i++) {
			inx[i] = X[i];
		}
	}  else if (op == 3) { // check P
		for (int i = 0; i <= size; i++) {
			inp[i] = P[i];
		}
	} else if (op == 4) {

		int p_size = (int) P[0];
		int x_size = (int) X[0];
		int k = (int) X[1];

		int res = 0;
		int l=x_size + 2;

		//legenDerK _pre
		double  s_derk=1.0;
		for(int j=2*k-1;j>0;j=j-2){
		        s_derk=j*s_derk;
		}

		for (int i_x = 2; i_x < l; i_x++, res += 3) {

				double x = X[i_x];
				//double xx = 2 * x;
				//init

				//legenVal
				double  t_val,b1_val=0,b2_val=0;
				double j_val;
				//legenDer
				double  t_der,b1_der=0,b2_der=0;
				double j_der;
				//legenDerK
				double  t_derk,b1_derk=0,b2_derk=0;
				double  A1_derk,A2_derk;
				double j_derk;

				for(int i =0; i<p_size; i++){
						int ii=p_size-1-i;

						//legenVal
						#pragma HLS PIPELINE
						{
							//printf("%f\n",P[i+1]);
							if(i<p_size-1){
								j_val=1.0*ii;
								t_val=(2*j_val+1)/(j_val+1)*x*b1_val-(j_val+1)/(j_val+2)*b2_val+P[i+1];
								b2_val=b1_val;
								b1_val=t_val;
							}else{
								b1_val=x*b1_val-b2_val/2+P[i+1];
							}
						}

						//legenDer
						#pragma HLS PIPELINE
						{
							if(i>0){
						        j_der=1.0*ii;
						        t_der=(2*j_der+3)/(j_der+1)*x*b1_der-(j_der+3)/(j_der+2)*b2_der+P[i];
						        b2_der=b1_der;
						        b1_der=t_der;
							}
						}
						//legenDerK
						#pragma HLS PIPELINE
						if(i>=k){
				        	j_derk=1.0*ii;
				        	A1_derk=(2*j_derk+2*k+1)/(j_derk+1)*x;
				        	A2_derk=-(j_derk+2*k+1)/(j_derk+2);
				        	t_derk=A1_derk*b1_derk+A2_derk*b2_derk+P[i-k+1];

				        	b2_derk=b1_derk;
				        	b1_derk=t_derk;
						}
					}

				//LegenVal =
				out[res+0] = b1_val;

				//LegenDer
				out[res + 1] = b1_der;

				//LegenDerK =
				out[res + 2] = s_derk*b1_derk;

		}
	}
	return 0;
}
