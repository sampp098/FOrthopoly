// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2019.1 (64-bit)
// Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
// ==============================================================
/***************************** Include Files *********************************/
#include "xlague.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XLague_CfgInitialize(XLague *InstancePtr, XLague_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Crtl_bus_BaseAddress = ConfigPtr->Crtl_bus_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XLague_Start(XLague *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLague_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XLAGUE_CRTL_BUS_ADDR_AP_CTRL) & 0x80;
    XLague_WriteReg(InstancePtr->Crtl_bus_BaseAddress, XLAGUE_CRTL_BUS_ADDR_AP_CTRL, Data | 0x01);
}

u32 XLague_IsDone(XLague *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLague_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XLAGUE_CRTL_BUS_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XLague_IsIdle(XLague *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLague_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XLAGUE_CRTL_BUS_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XLague_IsReady(XLague *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLague_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XLAGUE_CRTL_BUS_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XLague_EnableAutoRestart(XLague *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XLague_WriteReg(InstancePtr->Crtl_bus_BaseAddress, XLAGUE_CRTL_BUS_ADDR_AP_CTRL, 0x80);
}

void XLague_DisableAutoRestart(XLague *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XLague_WriteReg(InstancePtr->Crtl_bus_BaseAddress, XLAGUE_CRTL_BUS_ADDR_AP_CTRL, 0);
}

u32 XLague_Get_return(XLague *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLague_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XLAGUE_CRTL_BUS_ADDR_AP_RETURN);
    return Data;
}
void XLague_Set_op(XLague *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XLague_WriteReg(InstancePtr->Crtl_bus_BaseAddress, XLAGUE_CRTL_BUS_ADDR_OP_DATA, Data);
}

u32 XLague_Get_op(XLague *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLague_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XLAGUE_CRTL_BUS_ADDR_OP_DATA);
    return Data;
}

void XLague_Set_size(XLague *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XLague_WriteReg(InstancePtr->Crtl_bus_BaseAddress, XLAGUE_CRTL_BUS_ADDR_SIZE_DATA, Data);
}

u32 XLague_Get_size(XLague *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLague_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XLAGUE_CRTL_BUS_ADDR_SIZE_DATA);
    return Data;
}

void XLague_InterruptGlobalEnable(XLague *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XLague_WriteReg(InstancePtr->Crtl_bus_BaseAddress, XLAGUE_CRTL_BUS_ADDR_GIE, 1);
}

void XLague_InterruptGlobalDisable(XLague *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XLague_WriteReg(InstancePtr->Crtl_bus_BaseAddress, XLAGUE_CRTL_BUS_ADDR_GIE, 0);
}

void XLague_InterruptEnable(XLague *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XLague_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XLAGUE_CRTL_BUS_ADDR_IER);
    XLague_WriteReg(InstancePtr->Crtl_bus_BaseAddress, XLAGUE_CRTL_BUS_ADDR_IER, Register | Mask);
}

void XLague_InterruptDisable(XLague *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XLague_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XLAGUE_CRTL_BUS_ADDR_IER);
    XLague_WriteReg(InstancePtr->Crtl_bus_BaseAddress, XLAGUE_CRTL_BUS_ADDR_IER, Register & (~Mask));
}

void XLague_InterruptClear(XLague *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XLague_WriteReg(InstancePtr->Crtl_bus_BaseAddress, XLAGUE_CRTL_BUS_ADDR_ISR, Mask);
}

u32 XLague_InterruptGetEnabled(XLague *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XLague_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XLAGUE_CRTL_BUS_ADDR_IER);
}

u32 XLague_InterruptGetStatus(XLague *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XLague_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XLAGUE_CRTL_BUS_ADDR_ISR);
}

