// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2019.1 (64-bit)
// Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#include "xparameters.h"
#include "xlague.h"

extern XLague_Config XLague_ConfigTable[];

XLague_Config *XLague_LookupConfig(u16 DeviceId) {
	XLague_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XLAGUE_NUM_INSTANCES; Index++) {
		if (XLague_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XLague_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XLague_Initialize(XLague *InstancePtr, u16 DeviceId) {
	XLague_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XLague_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XLague_CfgInitialize(InstancePtr, ConfigPtr);
}

#endif

