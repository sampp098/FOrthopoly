// ==============================================================
// File generated on Sun May 19 04:40:23 +0430 2019
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2018.3 (64-bit)
// SW Build 2405991 on Thu Dec  6 23:38:27 MST 2018
// IP Build 2404404 on Fri Dec  7 01:43:56 MST 2018
// Copyright 1986-2018 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef XCHEB_H
#define XCHEB_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xcheb_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
#else
typedef struct {
    u16 DeviceId;
    u32 Crtl_bus_BaseAddress;
} XCheb_Config;
#endif

typedef struct {
    u32 Crtl_bus_BaseAddress;
    u32 IsReady;
} XCheb;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XCheb_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XCheb_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XCheb_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XCheb_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
int XCheb_Initialize(XCheb *InstancePtr, u16 DeviceId);
XCheb_Config* XCheb_LookupConfig(u16 DeviceId);
int XCheb_CfgInitialize(XCheb *InstancePtr, XCheb_Config *ConfigPtr);
#else
int XCheb_Initialize(XCheb *InstancePtr, const char* InstanceName);
int XCheb_Release(XCheb *InstancePtr);
#endif

void XCheb_Start(XCheb *InstancePtr);
u32 XCheb_IsDone(XCheb *InstancePtr);
u32 XCheb_IsIdle(XCheb *InstancePtr);
u32 XCheb_IsReady(XCheb *InstancePtr);
void XCheb_EnableAutoRestart(XCheb *InstancePtr);
void XCheb_DisableAutoRestart(XCheb *InstancePtr);
u32 XCheb_Get_return(XCheb *InstancePtr);

void XCheb_Set_op(XCheb *InstancePtr, u32 Data);
u32 XCheb_Get_op(XCheb *InstancePtr);
void XCheb_Set_size(XCheb *InstancePtr, u32 Data);
u32 XCheb_Get_size(XCheb *InstancePtr);

void XCheb_InterruptGlobalEnable(XCheb *InstancePtr);
void XCheb_InterruptGlobalDisable(XCheb *InstancePtr);
void XCheb_InterruptEnable(XCheb *InstancePtr, u32 Mask);
void XCheb_InterruptDisable(XCheb *InstancePtr, u32 Mask);
void XCheb_InterruptClear(XCheb *InstancePtr, u32 Mask);
u32 XCheb_InterruptGetEnabled(XCheb *InstancePtr);
u32 XCheb_InterruptGetStatus(XCheb *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
