#include <hls_stream.h>
#include <ap_axi_sdata.h>
#include <hls_math.h>
#define max_P_size 200

double P[max_P_size];
double X[max_P_size];
double B[max_P_size];


int cheb(int op, int size,double inx[max_P_size],double inp[max_P_size],double out[max_P_size*3]){
//#pragma HLS ARRAY_PARTITION variable=P complete dim=1

#pragma HLS INTERFACE s_axilite port=op		bundle=CRTL_BUS
#pragma HLS INTERFACE s_axilite port=size bundle=CRTL_BUS
#pragma HLS INTERFACE bram port=inx
#pragma HLS INTERFACE bram port=inp
#pragma HLS INTERFACE bram port=out
#pragma HLS INTERFACE s_axilite port=return bundle=CRTL_BUS

	if (op == 0) { //read P
		P[0] = size;
		for (int i = 0; i < size; i++) {
			P[i+1] = inp[i];
		}
	} else if (op == 1) { // read X
		X[0] = size;
		X[1] = inx[0];//k
		for (int i = 1; i < size+1; i++) {
			X[i+1] = inx[i];
		}
	}  else if (op == 2) { // check X
		for (int i = 0; i <= size; i++) {
			inx[i] = X[i];
		}
	}  else if (op == 3) { // check P
		for (int i = 0; i <= size; i++) {
			inp[i] = P[i];
		}
	} else if (op == 4) {

		int p_size = (int) P[0];
		int x_size = (int) X[0];
		int k = (int) X[1];

		int res = 0;
		int l=x_size + 2;
		for (int i_x = 2; i_x < l; i_x++, res += 3) {
			//if ((i_x)<l ) {
				double x = X[i_x];
				//init
				double xx = 2 * x;
				B[1] = 0.0;	//b2
				B[0] = 0.0;	//b1
				if (!(0 < p_size - 1)) {
					return 1;
				}
				if (!(hls::fabs(x) <= 1.0)) {
					return 2;
				}

				//cheb1Der
				double t, b1 = 0, b2 = 0;
				//cheb1DerK
				double s_k = 1.0, t_k, b1_k = 0, b2_k = 0;
				double j_k;
				for (int i = 0; i < p_size - 1; i++) {

				#pragma HLS PIPELINE
					//chebVal
					B[i + 2] = ((xx * B[i + 1]) - B[i]) + P[i + 1];

				#pragma HLS PIPELINE
					{
					//cheb1Der
						t = xx * b1 - b2 + (p_size - 1 - i) * P[i + 1];
						b2 = b1;
						b1 = t;
					}
					//cheb1DerK
				#pragma HLS PIPELINE
					if (i < k && i > 0) {
						s_k = 2 * s_k * i;
					} else if (i >= k) {
						j_k = 1.0 * (p_size - 1 - i);

						t_k = 2 * (j_k + k) / (j_k + 1) * x * b1_k
								- (j_k + 2 * k) / (j_k + 2) * b2_k
								+ (j_k + k) * P[i - k + 1];
						b2_k = b1_k;
						b1_k = t_k;
					}

				}
				//cheb1Der
				out[res] = (b1);

				//chebVal =
				out[res + 1] = (((x * B[p_size - 1 + 1]) - B[p_size - 1])
						+ P[p_size]);
				//cheb2Val=2*chebVal;

				t_k = k * (2 * x * b1_k - b2_k + P[p_size - k]);
				//cheb1DerK =
				out[res + 2] = (s_k * t_k);
			/*}
			if ((i_x+1)<l ) {
				double x = X[i_x+1];
				//init
				double xx = 2 * x;
				B[1] = 0.0;	//b2
				B[0] = 0.0;	//b1
				if (!(0 < p_size - 1)) {
					return 1;
				}
				if (!(hls::fabs(x) <= 1.0)) {
					return 2;
				}

				//cheb1Der
				double t, b1 = 0, b2 = 0;
				//cheb1DerK
				double s_k = 1.0, t_k, b1_k = 0, b2_k = 0;
				double j_k;
				for (int i = 0; i < p_size - 1; i++) {

#pragma HLS PIPELINE
					//chebVal
					B[i + 2] = ((xx * B[i + 1]) - B[i]) + P[i + 1];

#pragma HLS PIPELINE
					{
						//cheb1Der
						t = xx * b1 - b2 + (p_size - 1 - i) * P[i + 1];
						b2 = b1;
						b1 = t;
					}
					//cheb1DerK
#pragma HLS PIPELINE
					if (i < k && i > 0) {
						s_k = 2 * s_k * i;
					} else if (i >= k) {
						j_k = 1.0 * (p_size - 1 - i);

						t_k = 2 * (j_k + k) / (j_k + 1) * x * b1_k
								- (j_k + 2 * k) / (j_k + 2) * b2_k
								+ (j_k + k) * P[i - k + 1];
						b2_k = b1_k;
						b1_k = t_k;
					}

				}
				//cheb1Der
				out[res+3] = (b1);
				//chebVal =
				out[res + 4] = (((x * B[p_size - 1 + 1]) - B[p_size - 1])
						+ P[p_size]);
				//cheb2Val=2*chebVal;

				t_k = k * (2 * x * b1_k - b2_k + P[p_size - k]);
				//cheb1DerK =
				out[res + 5] = (s_k * t_k);
			}*/

		}
	}
	return 0;
}
