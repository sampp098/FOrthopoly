/*
 * Empty C++ Application
 */

#include <stdio.h>
#include <xparameters.h>
#include "xjacob.h"
#include "AxiTimerHelper.h"

XJacob doJacob;
XJacob_Config *doJacob_cfg;


#define SIZE_ARR 200
int inStreamData[SIZE_ARR];

union doubleToU64{
	double dval;
	u64 uval;
};
double u64_to_double(uint64_t val){
	doubleToU64 v;
	v.uval=val;
	return v.dval;
}
uint64_t double_to_u64(double val){
	doubleToU64 v;
	v.dval=val;
	return v.uval;
}
void initPeripherals(){
	//init doJacob Core
	printf("Initializing doJacob\n");

	doJacob_cfg = XJacob_LookupConfig(XPAR_XJACOB_0_DEVICE_ID);
	if(doJacob_cfg){
		int status = XJacob_CfgInitialize(&doJacob, doJacob_cfg);
		if(status != XST_SUCCESS){
			printf("Error initializing doJacob core\n");
		}
	}

}

void sendP(){
	double* P_Data=(double*) 0x42000000;
	double p[]=  {-28471492267.0/4194304.0,26980769367.0/2097152.0,-45904273683.0/4194304.0,17507317561.0/2097152.0,-11950694063.0/2097152.0,14559064751.0/4194304.0,-15766137527.0/8388608.0,3774819027.0/4194304.0,-1588096377.0/4194304.0,582044911.0/4194304.0,-367619987.0/8388608.0,49300931.0/4194304.0,-5507631.0/2097152.0,498871.0/1048576.0,-35209.0/524288.0,1817.0/262144.0,-61.0/131072.0,1.0/65536.0};
	u32 p_size = 18;
	int idx = 0;
	for (int i = p_size - 1; i >= 0; i--) {
		//P_Data[idx++] = i+2;
		P_Data[idx++]=p[i];
	}

	XJacob_Set_op(&doJacob, 0);
	XJacob_Set_size(&doJacob, p_size);
	XJacob_Start(&doJacob);
	while (!XJacob_IsDone(&doJacob));
}

void sendX(){
	double* X_Data=(double*) 0x44000000;
	double x = 0.65;
	int x_size=100;
	X_Data[0]= 4;//k
	X_Data[1]= 1.0;//alpha
	X_Data[2]= 2.0;//beta
	for(int i=3;i<x_size+1;i++){
		X_Data[i]= x;
	}

	XJacob_Set_op(&doJacob, 1);
	XJacob_Set_size(&doJacob, x_size);
	XJacob_Start(&doJacob);
	while (!XJacob_IsDone(&doJacob));
}
void checkp(int size){
	AxiTimerHelper timer;
	double* results=(double*) 0x42000000;

	XJacob_Set_op(&doJacob, 3);
	XJacob_Set_size(&doJacob, size);
	timer.startTimer();
	XJacob_Start(&doJacob);
	while (!XJacob_IsDone(&doJacob));

	timer.stopTimer();
	double timeHW= timer.getElapsedTimerInSeconds();
	printf("HW test finished in %f useconds\n",timeHW*1000000);

	int res=0;
	printf("p[%d]: %d\n",0, (int)results[res]);
	for(int i=0;i<size;i++){
		printf("p[%d]: %f\n",i, results[res++]);

	}
}

void checkx(int size){
	AxiTimerHelper timer;
	double* results=(double*) 0x44000000;

	XJacob_Set_op(&doJacob, 2);
	XJacob_Set_size(&doJacob, size);
	timer.startTimer();
	XJacob_Start(&doJacob);
	while (!XJacob_IsDone(&doJacob));

	timer.stopTimer();
	double timeHW= timer.getElapsedTimerInSeconds();
	printf("HW test finished in %f useconds\n",timeHW*1000000);

	int res=0;
	for(int i=0;i<size;i++){
		printf("x[%d]: %f\n",i, results[res++]);

	}
}
void getResult(int size){
	AxiTimerHelper timer;
	double* results=(double*) 0x40000000;

	XJacob_Set_op(&doJacob, 4);
	XJacob_Set_size(&doJacob, size);
	timer.startTimer();
	XJacob_Start(&doJacob);
	while (!XJacob_IsDone(&doJacob));

	timer.stopTimer();
	double timeHW= timer.getElapsedTimerInSeconds();
	printf("HW test finished in %f useconds\n",timeHW*1000000);

	int res=0;
	for(int i=0;i<size;i++){
		printf("---------------------\nval[%d]: %14.14e\n",i,results[res++]);
		printf("der[%d]: %14.14e\n",i,results[res++]);
		printf("derk[%d]: %14.14e\n",i,results[res++]);
	}
}

int main()
{

	initPeripherals();
	//printf("sending P \n");
	sendP();
	//printf("reading x \n");
	sendX();
	//checkp(18);
	//checkx(18);
	printf("done \n");
	//while(1){
	getResult(100);
	//}
	return 0;
}



