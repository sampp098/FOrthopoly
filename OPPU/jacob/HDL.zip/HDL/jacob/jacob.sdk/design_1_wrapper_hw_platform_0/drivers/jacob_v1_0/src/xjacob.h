// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2019.1 (64-bit)
// Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef XJACOB_H
#define XJACOB_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xjacob_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
#else
typedef struct {
    u16 DeviceId;
    u32 Crtl_bus_BaseAddress;
} XJacob_Config;
#endif

typedef struct {
    u32 Crtl_bus_BaseAddress;
    u32 IsReady;
} XJacob;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XJacob_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XJacob_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XJacob_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XJacob_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
int XJacob_Initialize(XJacob *InstancePtr, u16 DeviceId);
XJacob_Config* XJacob_LookupConfig(u16 DeviceId);
int XJacob_CfgInitialize(XJacob *InstancePtr, XJacob_Config *ConfigPtr);
#else
int XJacob_Initialize(XJacob *InstancePtr, const char* InstanceName);
int XJacob_Release(XJacob *InstancePtr);
#endif

void XJacob_Start(XJacob *InstancePtr);
u32 XJacob_IsDone(XJacob *InstancePtr);
u32 XJacob_IsIdle(XJacob *InstancePtr);
u32 XJacob_IsReady(XJacob *InstancePtr);
void XJacob_EnableAutoRestart(XJacob *InstancePtr);
void XJacob_DisableAutoRestart(XJacob *InstancePtr);
u32 XJacob_Get_return(XJacob *InstancePtr);

void XJacob_Set_op(XJacob *InstancePtr, u32 Data);
u32 XJacob_Get_op(XJacob *InstancePtr);
void XJacob_Set_size(XJacob *InstancePtr, u32 Data);
u32 XJacob_Get_size(XJacob *InstancePtr);

void XJacob_InterruptGlobalEnable(XJacob *InstancePtr);
void XJacob_InterruptGlobalDisable(XJacob *InstancePtr);
void XJacob_InterruptEnable(XJacob *InstancePtr, u32 Mask);
void XJacob_InterruptDisable(XJacob *InstancePtr, u32 Mask);
void XJacob_InterruptClear(XJacob *InstancePtr, u32 Mask);
u32 XJacob_InterruptGetEnabled(XJacob *InstancePtr);
u32 XJacob_InterruptGetStatus(XJacob *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
