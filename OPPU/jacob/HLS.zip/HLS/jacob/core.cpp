#include <hls_stream.h>
#include <ap_axi_sdata.h>
#include <hls_math.h>
#define max_P_size 200

double P[max_P_size];
double X[max_P_size];

double A_val[max_P_size];
double B_val[max_P_size];
double C_val[max_P_size];

//----------------------- The three-term recurrence coefficients of jacobi polynomial ----------------------------------
void RecurCoefJacob (double n, double alpha, double beta,  double *A, double *B, double *C)
{
    int i;
    double j;
    for (i=1;i<=n+2;i++)
    {
        j=1.0*i;
        A[i-1]=(2*j+alpha+beta-1)*(2*j+alpha+beta)/(2*j*(j+alpha+beta));
        B[i-1]=(alpha*alpha-beta*beta)*(2*j+alpha+beta-1)/(2*j*(j+alpha+beta)*(2*j+alpha+beta-2));
        C[i-1]=(j-1+alpha)*(j-1+beta)*(2*j+alpha+beta)/(j*(j+alpha+beta)*(2*j+alpha+beta-2));
    }
}

int jacob(int op, int size,double inx[max_P_size],double inp[max_P_size],double out[max_P_size*3]){
#pragma HLS INTERFACE s_axilite port=op		bundle=CRTL_BUS
#pragma HLS INTERFACE s_axilite port=size bundle=CRTL_BUS
#pragma HLS INTERFACE bram port=inx
#pragma HLS INTERFACE bram port=inp
#pragma HLS INTERFACE bram port=out
#pragma HLS INTERFACE s_axilite port=return bundle=CRTL_BUS

	if (op == 0) { //read P
		P[0] = size;
		for (int i = 0; i < size; i++) {
			P[i+1] = inp[i];
		}
	} else if (op == 1) { // read X
		X[0] = size;
		X[1] = inx[0];//k
		X[2] = inx[1];//alpha
		X[3] = inx[2];//beta
		for (int i = 3; i < size+3; i++) {
			X[i+1] = inx[i];
		}
	}  else if (op == 2) { // check X
		for (int i = 0; i <= size; i++) {
			inx[i] = X[i];
		}
	}  else if (op == 3) { // check P
		for (int i = 0; i <= size; i++) {
			inp[i] = P[i];
		}
	} else if (op == 4) {

		int p_size = (int) P[0];
		int x_size = (int) X[0];
		int k = (int) X[1];
		double alpha= X[2];
		double beta= X[3];

		int res = 0;
		int l=x_size + 4;

		//pre Gegen calc
		//Val
		RecurCoefJacob(p_size-1,alpha,beta,A_val,B_val,C_val);
		//jacobDer
		double C_der=0.5;

		//DerK
	    double C_derk=1.0;
		#pragma HLS PIPELINE
		for(int i=k;i>0;i--)
		{
			C_derk=C_derk/2.0;
		}

		for (int i_x = 4; i_x < l; i_x++, res += 3) {

				double x = X[i_x];
				//double xx = 2 * x;
				//init
				//jacobVal
				double  t_val,b1_val=0,b2_val=0;
				double j_val;

				//jacobDer
				double  t_der,b1_der=0,b2_der=0;
				double Ac_der, A1_der, A2_der;
				double a10_der,a11_der,a12_der,a20_der,a21_der;
				double j_der;
				//jacobDerK

			    double  t_derk,b1_derk=0,b2_derk=0;
			    double A1_derk, A2_derk,s_derk;
			    double a10_derk,a11_derk,a12_derk,a20_derk,a21_derk;

				double j_k;
				for(int i =0; i<p_size-1; i++){
					int ii=p_size-1-i;

					//jacobVal
					#pragma HLS PIPELINE
					{
						t_val=(*(A_val+ii)*x+*(B_val+ii))*b1_val-*(C_val+ii+1)*b2_val+P[i];
						b2_val=b1_val;
						b1_val=t_val;
					}

					//jacobDer
					#pragma HLS PIPELINE
					{
						if(i>0){
					        j_der=1.0*ii;
					//-------------recurrence coefficients-----------------------//
					        Ac_der=j_der+2+alpha+beta;
					        a10_der=(2*j_der+3+alpha+beta)/((2*j_der+2)*(j_der+3+alpha+beta));
					        a11_der=(2*j_der+4+alpha+beta)*x;
					        a12_der=((alpha-beta)*(alpha+beta+2))/(alpha+beta+2*j_der+2);
					        A1_der=a10_der*(a11_der+a12_der);
					        a20_der=-(j_der+2+alpha)*(j_der+2+beta)/((j_der+2)*(alpha+beta+j_der+4));
					        a21_der=(alpha+beta+2*j_der+6)/(alpha+beta+2*j_der+4);
					        A2_der=a20_der*a21_der;
					//--------------iteration-----------------------------------//
					        t_der=A1_der*b1_der+A2_der*b2_der+Ac_der*P[i-1];

					        b2_der=b1_der;
					        b1_der=t_der;
						}
					}
					//jacobDerK
					#pragma HLS PIPELINE
					if(i>=k){

				        //-------------recurrence coefficients-----------------------//
				        s_derk=1.0;
				        for(int j=1;j<=k;j++){
				        	s_derk=s_derk*(alpha+beta+ii+k+j);
				        }
				        a10_derk=(2*ii+1+2*k+alpha+beta)/((2*ii+2)*(ii+1+2*k+alpha+beta));
				        a11_derk=(2*ii+2+2*k+alpha+beta)*x;
				        a12_derk=((alpha-beta)*(alpha+beta+2*k))/(alpha+beta+2*ii+2*k);
				        A1_derk=a10_derk*(a11_derk+a12_derk);

				        a20_derk=-(ii+1+k+alpha)*(ii+1+k+beta)/((ii+2)*(alpha+beta+ii+2+2*k));
				        a21_derk=(alpha+beta+2*ii+4+2*k)/(alpha+beta+2*ii+2+2*k);
				        A2_derk=a20_derk*a21_derk;
				        //--------------iteration-----------------------------------//
				        t_derk=A1_derk*b1_derk+A2_derk*b2_derk+s_derk*P[i-k];

				        b2_derk=b1_derk;
				        b1_derk=t_derk;
					}
				}
				//JacobVal =
				out[res+0] = b1_val;

				//JacobDer
				out[res + 1] = C_der*b1_der;
				//cheb2Val=2*chebVal;

				//JacobDerK =
				out[res + 2] = C_derk*b1_derk;

		}
	}
	return 0;
}
