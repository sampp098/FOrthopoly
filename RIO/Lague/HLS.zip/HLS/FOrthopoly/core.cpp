#include <hls_stream.h>
#include <ap_axi_sdata.h>
#include <hls_math.h>
#define max_P_size 200

//////////////////////////

void RecurCoefLague (double n, double alpha,  double *A, double *B, double *C)
{
    int i;
    double j;
    for (i=1;i<=n+2;i++)
    {
        j=1.0*i;
        *(A+i-1)=-1/j;
        *(B+i-1)=(2*j+alpha-1)/j;
        *(C+i-1)=(j-1+alpha)/j;
    }
}

/* LagueVal evaluates a series of Laguerre polynomial at the point x, which is in (0, +infty).*/
double LagueVal(double *P, unsigned int n, double x, double alpha)
{
    //assert ( 0 < n);
    //assert (x>0);
    //assert (alpha>-1.0);
    double  t,b1=0,b2=0;
    int j;

    double A[max_P_size+2];
    double B[max_P_size+2];
    double C[max_P_size+2];

    RecurCoefLague(n,alpha,A,B,C);

    for(j=n; j>=0; j--) 
    {
        t=(*(A+j)*x+*(B+j))*b1-*(C+j+1)*b2+P[j];

        b2=b1;
        b1=t;
    }

    return b1;
}

/*LagueDer evaluates  the first derivative of a series of Laguerre polynomial at the point x, which is in (0, +infty). */
double LagueDer(double *P, unsigned int n, double x, double alpha)
{
    //assert ( 0 < n);
    //assert (x>0);
    //assert (alpha>-1.0);
    double  t,b1=0,b2=0;
    double A1,A2;
    int i;
    double j;
    double C=1;

    for(i=n-1; i>=0; i--) 
    {
        j=1.0*i;
//-------------recurrence coefficients-----------------------//
        A1=-x/(j+1)+(2*j+alpha+2)/(j+1);
        A2=-(j+alpha+2)/(j+2);
//--------------iteration-----------------------------------//
        t=A1*b1+A2*b2-P[i+1];

        b2=b1;
        b1=t;
    }
    return  C*b1;
}
/*LagueDerK evaluates  the k-th derivative of a series of Laguerre polynomial at the point x, which is in (0, +infty). */
double LagueDerK(double *P, unsigned int n, double x, double alpha, unsigned int k)
{
    //assert ( 0 < n);
    //assert (x>0);
    //assert (alpha>-1.0);
    double  t,b1=0,b2=0;
    double A1,A2;
    int i;
    double j;
    int C=1;
    for(i=k;i>0;i--)
    {
        C=-C;
    }

    for(i=n-k; i>=0; i--) 
    {
        j=1.0*i;
//-------------recurrence coefficients-----------------------//
        A1=-x/(j+1)+(2*j+alpha+k+1)/(j+1);
        A2=-(j+alpha+k+1)/(j+2);
//--------------iteration-----------------------------------//
        t=A1*b1+A2*b2+P[i+k];

        b2=b1;
        b1=t;
    }
    return  C*b1;
}


////////////////////////////

int lague(double &Val,double &Der,double &DerK,unsigned int size,unsigned int k,double p[max_P_size], double x, double alpha){

#pragma HLS INTERFACE s_axilite port=k		bundle=CRTL_BUS
#pragma HLS INTERFACE s_axilite port=size bundle=CRTL_BUS
#pragma HLS INTERFACE s_axilite port=x bundle=CRTL_BUS
#pragma HLS INTERFACE s_axilite port=alpha bundle=CRTL_BUS

#pragma HLS INTERFACE s_axilite port=Val bundle=CRTL_BUS
#pragma HLS INTERFACE s_axilite port=Der bundle=CRTL_BUS
#pragma HLS INTERFACE s_axilite port=DerK bundle=CRTL_BUS
#pragma HLS INTERFACE s_axilite port=return bundle=CRTL_BUS

#pragma HLS INTERFACE bram port=p

	Val= LagueVal(p, size, x, alpha);
	Der= LagueDer(p, size, x, alpha);
	DerK= LagueDerK(p, size, x, alpha, k);
	return 0;
}
