#include <hls_stream.h>
#include <ap_axi_sdata.h>
#include <hls_math.h>
#define max_P_size 200

//////////////////////////

double LegenVal(double *P, unsigned int n, double x)
{
    assert ( 0 < n);
    assert (fabs(x)<=1.0);
    double  t,b1=0,b2=0;
    int j;
    double i;

    for(j=n; j>=1; j--)
    {
        i=1.0*j;
        t=(2*i+1)/(i+1)*x*b1-(i+1)/(i+2)*b2+P[j];
        b2=b1;
        b1=t;
    }
    return x*b1-b2/2+P[0];
}

/*LegenDer evaluates  the first derivative of a series of legendre polynomial at the point x, which is in [-1, 1]. */
double LegenDer(double *P, unsigned int n, double x)
{
    assert ( 0 < n);
    assert (fabs(x)<=1.0);
    double  t,b1=0,b2=0;
    int j;
    double i;

    for(j=n-1; j>=0; j--)
    {
        i=1.0*j;
        t=(2*i+3)/(i+1)*x*b1-(i+3)/(i+2)*b2+P[j+1];
        b2=b1;
        b1=t;
    }
    return  b1;
}

/*LegenDerK evaluates  the k-th derivative of a series of legendre polynomial at the point x, which is in [-1, 1]. */
double LegenDerK(double *P, unsigned int n, double x, unsigned int k)
{
    assert ( 0 < n);
    assert (fabs(x)<=1.0);
    double  s=1.0,t,b1=0,b2=0;
    int j;
    double i;

    for(j=2*k-1;j>0;j=j-2)
    {
        s=j*s;
    }
    double  A1,A2;

    for(j=n-k; j>=0; j--)
    {
        i=1.0*j;
        A1=(2*i+2*k+1)/(i+1)*x;
        A2=-(i+2*k+1)/(i+2);
        t=A1*b1+A2*b2+P[j+k];

        b2=b1;
        b1=t;
    }
    return  s*b1;
}

////////////////////////////

int legen(double &Val,double &Der,double &DerK,unsigned int size,unsigned int k,double p[max_P_size], double x){

#pragma HLS INTERFACE s_axilite port=k		bundle=CRTL_BUS
#pragma HLS INTERFACE s_axilite port=size bundle=CRTL_BUS
#pragma HLS INTERFACE s_axilite port=x bundle=CRTL_BUS

#pragma HLS INTERFACE s_axilite port=Val bundle=CRTL_BUS
#pragma HLS INTERFACE s_axilite port=Der bundle=CRTL_BUS
#pragma HLS INTERFACE s_axilite port=DerK bundle=CRTL_BUS
#pragma HLS INTERFACE s_axilite port=return bundle=CRTL_BUS

#pragma HLS INTERFACE bram port=p

	Val= LegenVal(p, size, x);
	Der= LegenDer(p, size, x);
	DerK= LegenDerK(p, size, x, k);
	return 0;
}
