// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2019.1 (64-bit)
// Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
// ==============================================================
/***************************** Include Files *********************************/
#include "xlegen.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XLegen_CfgInitialize(XLegen *InstancePtr, XLegen_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Crtl_bus_BaseAddress = ConfigPtr->Crtl_bus_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XLegen_Start(XLegen *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLegen_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XLEGEN_CRTL_BUS_ADDR_AP_CTRL) & 0x80;
    XLegen_WriteReg(InstancePtr->Crtl_bus_BaseAddress, XLEGEN_CRTL_BUS_ADDR_AP_CTRL, Data | 0x01);
}

u32 XLegen_IsDone(XLegen *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLegen_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XLEGEN_CRTL_BUS_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XLegen_IsIdle(XLegen *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLegen_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XLEGEN_CRTL_BUS_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XLegen_IsReady(XLegen *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLegen_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XLEGEN_CRTL_BUS_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XLegen_EnableAutoRestart(XLegen *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XLegen_WriteReg(InstancePtr->Crtl_bus_BaseAddress, XLEGEN_CRTL_BUS_ADDR_AP_CTRL, 0x80);
}

void XLegen_DisableAutoRestart(XLegen *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XLegen_WriteReg(InstancePtr->Crtl_bus_BaseAddress, XLEGEN_CRTL_BUS_ADDR_AP_CTRL, 0);
}

u32 XLegen_Get_return(XLegen *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLegen_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XLEGEN_CRTL_BUS_ADDR_AP_RETURN);
    return Data;
}
u64 XLegen_Get_Val_r(XLegen *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLegen_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XLEGEN_CRTL_BUS_ADDR_VAL_R_DATA);
    Data += (u64)XLegen_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XLEGEN_CRTL_BUS_ADDR_VAL_R_DATA + 4) << 32;
    return Data;
}

u32 XLegen_Get_Val_r_vld(XLegen *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLegen_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XLEGEN_CRTL_BUS_ADDR_VAL_R_CTRL);
    return Data & 0x1;
}

u64 XLegen_Get_Der(XLegen *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLegen_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XLEGEN_CRTL_BUS_ADDR_DER_DATA);
    Data += (u64)XLegen_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XLEGEN_CRTL_BUS_ADDR_DER_DATA + 4) << 32;
    return Data;
}

u32 XLegen_Get_Der_vld(XLegen *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLegen_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XLEGEN_CRTL_BUS_ADDR_DER_CTRL);
    return Data & 0x1;
}

u64 XLegen_Get_DerK(XLegen *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLegen_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XLEGEN_CRTL_BUS_ADDR_DERK_DATA);
    Data += (u64)XLegen_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XLEGEN_CRTL_BUS_ADDR_DERK_DATA + 4) << 32;
    return Data;
}

u32 XLegen_Get_DerK_vld(XLegen *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLegen_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XLEGEN_CRTL_BUS_ADDR_DERK_CTRL);
    return Data & 0x1;
}

void XLegen_Set_size(XLegen *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XLegen_WriteReg(InstancePtr->Crtl_bus_BaseAddress, XLEGEN_CRTL_BUS_ADDR_SIZE_DATA, Data);
}

u32 XLegen_Get_size(XLegen *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLegen_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XLEGEN_CRTL_BUS_ADDR_SIZE_DATA);
    return Data;
}

void XLegen_Set_k(XLegen *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XLegen_WriteReg(InstancePtr->Crtl_bus_BaseAddress, XLEGEN_CRTL_BUS_ADDR_K_DATA, Data);
}

u32 XLegen_Get_k(XLegen *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLegen_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XLEGEN_CRTL_BUS_ADDR_K_DATA);
    return Data;
}

void XLegen_Set_x(XLegen *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XLegen_WriteReg(InstancePtr->Crtl_bus_BaseAddress, XLEGEN_CRTL_BUS_ADDR_X_DATA, (u32)(Data));
    XLegen_WriteReg(InstancePtr->Crtl_bus_BaseAddress, XLEGEN_CRTL_BUS_ADDR_X_DATA + 4, (u32)(Data >> 32));
}

u64 XLegen_Get_x(XLegen *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLegen_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XLEGEN_CRTL_BUS_ADDR_X_DATA);
    Data += (u64)XLegen_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XLEGEN_CRTL_BUS_ADDR_X_DATA + 4) << 32;
    return Data;
}

void XLegen_InterruptGlobalEnable(XLegen *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XLegen_WriteReg(InstancePtr->Crtl_bus_BaseAddress, XLEGEN_CRTL_BUS_ADDR_GIE, 1);
}

void XLegen_InterruptGlobalDisable(XLegen *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XLegen_WriteReg(InstancePtr->Crtl_bus_BaseAddress, XLEGEN_CRTL_BUS_ADDR_GIE, 0);
}

void XLegen_InterruptEnable(XLegen *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XLegen_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XLEGEN_CRTL_BUS_ADDR_IER);
    XLegen_WriteReg(InstancePtr->Crtl_bus_BaseAddress, XLEGEN_CRTL_BUS_ADDR_IER, Register | Mask);
}

void XLegen_InterruptDisable(XLegen *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XLegen_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XLEGEN_CRTL_BUS_ADDR_IER);
    XLegen_WriteReg(InstancePtr->Crtl_bus_BaseAddress, XLEGEN_CRTL_BUS_ADDR_IER, Register & (~Mask));
}

void XLegen_InterruptClear(XLegen *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XLegen_WriteReg(InstancePtr->Crtl_bus_BaseAddress, XLEGEN_CRTL_BUS_ADDR_ISR, Mask);
}

u32 XLegen_InterruptGetEnabled(XLegen *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XLegen_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XLEGEN_CRTL_BUS_ADDR_IER);
}

u32 XLegen_InterruptGetStatus(XLegen *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XLegen_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XLEGEN_CRTL_BUS_ADDR_ISR);
}

