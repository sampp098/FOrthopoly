/*
 * Empty C++ Application
 */

#include <stdio.h>
#include <xparameters.h>
#include "xherm2.h"
#include "AxiTimerHelper.h"

XHerm2 doCheb;
XHerm2_Config *doCheb_cfg;


#define SIZE_ARR 200
int inStreamData[SIZE_ARR];

union doubleToU64{
	double dval;
	u64 uval;
};
double u64_to_double(uint64_t val){
	doubleToU64 v;
	v.uval=val;
	return v.dval;
}
uint64_t double_to_u64(double val){
	doubleToU64 v;
	v.dval=val;
	return v.uval;
}
void initPeripherals(){
	//init doCheb Core
	printf("Initializing doCheb\n");

	doCheb_cfg = XHerm2_LookupConfig(XPAR_XHERM2_0_DEVICE_ID);
	if(doCheb_cfg){
		int status = XHerm2_CfgInitialize(&doCheb, doCheb_cfg);
		if(status != XST_SUCCESS){
			printf("Error initializing doCheb core\n");
		}
	}

}


void getResult(int run){
	AxiTimerHelper timer;
	double results[run*3];


	double* P_Data=(double*) 0x40000000;
	double p[]=  {-28471492267.0/4194304.0,26980769367.0/2097152.0,-45904273683.0/4194304.0,17507317561.0/2097152.0,-11950694063.0/2097152.0,14559064751.0/4194304.0,-15766137527.0/8388608.0,3774819027.0/4194304.0,-1588096377.0/4194304.0,582044911.0/4194304.0,-367619987.0/8388608.0,49300931.0/4194304.0,-5507631.0/2097152.0,498871.0/1048576.0,-35209.0/524288.0,1817.0/262144.0,-61.0/131072.0,1.0/65536.0};
	int size = 18;
	int k=4;
	double x = 0.65;

	for(int i=0; i<size; i++){
		P_Data[i]=p[i];
	}

	XHerm2_Set_size(&doCheb, size);
	XHerm2_Set_k(&doCheb, k);
	timer.startTimer();
	for(int i=0,idx=0; i<run; i++,idx+=3){
		XHerm2_Set_x(&doCheb, x);
		XHerm2_Start(&doCheb);
		while (!XHerm2_IsDone(&doCheb));
		results[idx+0]=XHerm2_Get_Val_r(&doCheb);
		results[idx+1]=XHerm2_Get_Der(&doCheb);
		results[idx+2]=XHerm2_Get_DerK(&doCheb);
	}
	timer.stopTimer();
	double timeHW= timer.getElapsedTimerInSeconds();
	printf("HW test finished in %f useconds\n",timeHW*1000000);

	int res=0;
	for(int i=0;i<run;i++){
		printf("---------------------\nval[%d]: %14.14e\n",i,results[res++]);
		printf("der[%d]: %14.14e\n",i,results[res++]);
		printf("derk[%d]: %14.14e\n",i,results[res++]);
	}
}

int main()
{

	initPeripherals();

	getResult(100);
	//}
	return 0;
}


