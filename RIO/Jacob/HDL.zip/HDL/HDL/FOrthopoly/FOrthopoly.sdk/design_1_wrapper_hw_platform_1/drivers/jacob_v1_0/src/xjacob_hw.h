// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2019.1 (64-bit)
// Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
// ==============================================================
// CRTL_BUS
// 0x00 : Control signals
//        bit 0  - ap_start (Read/Write/COH)
//        bit 1  - ap_done (Read/COR)
//        bit 2  - ap_idle (Read)
//        bit 3  - ap_ready (Read)
//        bit 7  - auto_restart (Read/Write)
//        others - reserved
// 0x04 : Global Interrupt Enable Register
//        bit 0  - Global Interrupt Enable (Read/Write)
//        others - reserved
// 0x08 : IP Interrupt Enable Register (Read/Write)
//        bit 0  - Channel 0 (ap_done)
//        bit 1  - Channel 1 (ap_ready)
//        others - reserved
// 0x0c : IP Interrupt Status Register (Read/TOW)
//        bit 0  - Channel 0 (ap_done)
//        bit 1  - Channel 1 (ap_ready)
//        others - reserved
// 0x10 : Data signal of ap_return
//        bit 31~0 - ap_return[31:0] (Read)
// 0x18 : Data signal of Val_r
//        bit 31~0 - Val_r[31:0] (Read)
// 0x1c : Data signal of Val_r
//        bit 31~0 - Val_r[63:32] (Read)
// 0x20 : Control signal of Val_r
//        bit 0  - Val_r_ap_vld (Read/COR)
//        others - reserved
// 0x24 : Data signal of Der
//        bit 31~0 - Der[31:0] (Read)
// 0x28 : Data signal of Der
//        bit 31~0 - Der[63:32] (Read)
// 0x2c : Control signal of Der
//        bit 0  - Der_ap_vld (Read/COR)
//        others - reserved
// 0x30 : Data signal of DerK
//        bit 31~0 - DerK[31:0] (Read)
// 0x34 : Data signal of DerK
//        bit 31~0 - DerK[63:32] (Read)
// 0x38 : Control signal of DerK
//        bit 0  - DerK_ap_vld (Read/COR)
//        others - reserved
// 0x3c : Data signal of size
//        bit 31~0 - size[31:0] (Read/Write)
// 0x40 : reserved
// 0x44 : Data signal of k
//        bit 31~0 - k[31:0] (Read/Write)
// 0x48 : reserved
// 0x4c : Data signal of x
//        bit 31~0 - x[31:0] (Read/Write)
// 0x50 : Data signal of x
//        bit 31~0 - x[63:32] (Read/Write)
// 0x54 : reserved
// 0x58 : Data signal of alpha
//        bit 31~0 - alpha[31:0] (Read/Write)
// 0x5c : Data signal of alpha
//        bit 31~0 - alpha[63:32] (Read/Write)
// 0x60 : reserved
// 0x64 : Data signal of beta
//        bit 31~0 - beta[31:0] (Read/Write)
// 0x68 : Data signal of beta
//        bit 31~0 - beta[63:32] (Read/Write)
// 0x6c : reserved
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define XJACOB_CRTL_BUS_ADDR_AP_CTRL    0x00
#define XJACOB_CRTL_BUS_ADDR_GIE        0x04
#define XJACOB_CRTL_BUS_ADDR_IER        0x08
#define XJACOB_CRTL_BUS_ADDR_ISR        0x0c
#define XJACOB_CRTL_BUS_ADDR_AP_RETURN  0x10
#define XJACOB_CRTL_BUS_BITS_AP_RETURN  32
#define XJACOB_CRTL_BUS_ADDR_VAL_R_DATA 0x18
#define XJACOB_CRTL_BUS_BITS_VAL_R_DATA 64
#define XJACOB_CRTL_BUS_ADDR_VAL_R_CTRL 0x20
#define XJACOB_CRTL_BUS_ADDR_DER_DATA   0x24
#define XJACOB_CRTL_BUS_BITS_DER_DATA   64
#define XJACOB_CRTL_BUS_ADDR_DER_CTRL   0x2c
#define XJACOB_CRTL_BUS_ADDR_DERK_DATA  0x30
#define XJACOB_CRTL_BUS_BITS_DERK_DATA  64
#define XJACOB_CRTL_BUS_ADDR_DERK_CTRL  0x38
#define XJACOB_CRTL_BUS_ADDR_SIZE_DATA  0x3c
#define XJACOB_CRTL_BUS_BITS_SIZE_DATA  32
#define XJACOB_CRTL_BUS_ADDR_K_DATA     0x44
#define XJACOB_CRTL_BUS_BITS_K_DATA     32
#define XJACOB_CRTL_BUS_ADDR_X_DATA     0x4c
#define XJACOB_CRTL_BUS_BITS_X_DATA     64
#define XJACOB_CRTL_BUS_ADDR_ALPHA_DATA 0x58
#define XJACOB_CRTL_BUS_BITS_ALPHA_DATA 64
#define XJACOB_CRTL_BUS_ADDR_BETA_DATA  0x64
#define XJACOB_CRTL_BUS_BITS_BETA_DATA  64

