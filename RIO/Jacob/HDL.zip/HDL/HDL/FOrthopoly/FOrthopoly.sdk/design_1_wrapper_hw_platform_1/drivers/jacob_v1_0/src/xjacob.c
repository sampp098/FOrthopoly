// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2019.1 (64-bit)
// Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
// ==============================================================
/***************************** Include Files *********************************/
#include "xjacob.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XJacob_CfgInitialize(XJacob *InstancePtr, XJacob_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Crtl_bus_BaseAddress = ConfigPtr->Crtl_bus_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XJacob_Start(XJacob *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XJacob_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XJACOB_CRTL_BUS_ADDR_AP_CTRL) & 0x80;
    XJacob_WriteReg(InstancePtr->Crtl_bus_BaseAddress, XJACOB_CRTL_BUS_ADDR_AP_CTRL, Data | 0x01);
}

u32 XJacob_IsDone(XJacob *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XJacob_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XJACOB_CRTL_BUS_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XJacob_IsIdle(XJacob *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XJacob_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XJACOB_CRTL_BUS_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XJacob_IsReady(XJacob *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XJacob_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XJACOB_CRTL_BUS_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XJacob_EnableAutoRestart(XJacob *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XJacob_WriteReg(InstancePtr->Crtl_bus_BaseAddress, XJACOB_CRTL_BUS_ADDR_AP_CTRL, 0x80);
}

void XJacob_DisableAutoRestart(XJacob *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XJacob_WriteReg(InstancePtr->Crtl_bus_BaseAddress, XJACOB_CRTL_BUS_ADDR_AP_CTRL, 0);
}

u32 XJacob_Get_return(XJacob *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XJacob_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XJACOB_CRTL_BUS_ADDR_AP_RETURN);
    return Data;
}
u64 XJacob_Get_Val_r(XJacob *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XJacob_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XJACOB_CRTL_BUS_ADDR_VAL_R_DATA);
    Data += (u64)XJacob_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XJACOB_CRTL_BUS_ADDR_VAL_R_DATA + 4) << 32;
    return Data;
}

u32 XJacob_Get_Val_r_vld(XJacob *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XJacob_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XJACOB_CRTL_BUS_ADDR_VAL_R_CTRL);
    return Data & 0x1;
}

u64 XJacob_Get_Der(XJacob *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XJacob_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XJACOB_CRTL_BUS_ADDR_DER_DATA);
    Data += (u64)XJacob_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XJACOB_CRTL_BUS_ADDR_DER_DATA + 4) << 32;
    return Data;
}

u32 XJacob_Get_Der_vld(XJacob *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XJacob_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XJACOB_CRTL_BUS_ADDR_DER_CTRL);
    return Data & 0x1;
}

u64 XJacob_Get_DerK(XJacob *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XJacob_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XJACOB_CRTL_BUS_ADDR_DERK_DATA);
    Data += (u64)XJacob_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XJACOB_CRTL_BUS_ADDR_DERK_DATA + 4) << 32;
    return Data;
}

u32 XJacob_Get_DerK_vld(XJacob *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XJacob_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XJACOB_CRTL_BUS_ADDR_DERK_CTRL);
    return Data & 0x1;
}

void XJacob_Set_size(XJacob *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XJacob_WriteReg(InstancePtr->Crtl_bus_BaseAddress, XJACOB_CRTL_BUS_ADDR_SIZE_DATA, Data);
}

u32 XJacob_Get_size(XJacob *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XJacob_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XJACOB_CRTL_BUS_ADDR_SIZE_DATA);
    return Data;
}

void XJacob_Set_k(XJacob *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XJacob_WriteReg(InstancePtr->Crtl_bus_BaseAddress, XJACOB_CRTL_BUS_ADDR_K_DATA, Data);
}

u32 XJacob_Get_k(XJacob *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XJacob_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XJACOB_CRTL_BUS_ADDR_K_DATA);
    return Data;
}

void XJacob_Set_x(XJacob *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XJacob_WriteReg(InstancePtr->Crtl_bus_BaseAddress, XJACOB_CRTL_BUS_ADDR_X_DATA, (u32)(Data));
    XJacob_WriteReg(InstancePtr->Crtl_bus_BaseAddress, XJACOB_CRTL_BUS_ADDR_X_DATA + 4, (u32)(Data >> 32));
}

u64 XJacob_Get_x(XJacob *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XJacob_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XJACOB_CRTL_BUS_ADDR_X_DATA);
    Data += (u64)XJacob_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XJACOB_CRTL_BUS_ADDR_X_DATA + 4) << 32;
    return Data;
}

void XJacob_Set_alpha(XJacob *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XJacob_WriteReg(InstancePtr->Crtl_bus_BaseAddress, XJACOB_CRTL_BUS_ADDR_ALPHA_DATA, (u32)(Data));
    XJacob_WriteReg(InstancePtr->Crtl_bus_BaseAddress, XJACOB_CRTL_BUS_ADDR_ALPHA_DATA + 4, (u32)(Data >> 32));
}

u64 XJacob_Get_alpha(XJacob *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XJacob_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XJACOB_CRTL_BUS_ADDR_ALPHA_DATA);
    Data += (u64)XJacob_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XJACOB_CRTL_BUS_ADDR_ALPHA_DATA + 4) << 32;
    return Data;
}

void XJacob_Set_beta(XJacob *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XJacob_WriteReg(InstancePtr->Crtl_bus_BaseAddress, XJACOB_CRTL_BUS_ADDR_BETA_DATA, (u32)(Data));
    XJacob_WriteReg(InstancePtr->Crtl_bus_BaseAddress, XJACOB_CRTL_BUS_ADDR_BETA_DATA + 4, (u32)(Data >> 32));
}

u64 XJacob_Get_beta(XJacob *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XJacob_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XJACOB_CRTL_BUS_ADDR_BETA_DATA);
    Data += (u64)XJacob_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XJACOB_CRTL_BUS_ADDR_BETA_DATA + 4) << 32;
    return Data;
}

void XJacob_InterruptGlobalEnable(XJacob *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XJacob_WriteReg(InstancePtr->Crtl_bus_BaseAddress, XJACOB_CRTL_BUS_ADDR_GIE, 1);
}

void XJacob_InterruptGlobalDisable(XJacob *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XJacob_WriteReg(InstancePtr->Crtl_bus_BaseAddress, XJACOB_CRTL_BUS_ADDR_GIE, 0);
}

void XJacob_InterruptEnable(XJacob *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XJacob_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XJACOB_CRTL_BUS_ADDR_IER);
    XJacob_WriteReg(InstancePtr->Crtl_bus_BaseAddress, XJACOB_CRTL_BUS_ADDR_IER, Register | Mask);
}

void XJacob_InterruptDisable(XJacob *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XJacob_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XJACOB_CRTL_BUS_ADDR_IER);
    XJacob_WriteReg(InstancePtr->Crtl_bus_BaseAddress, XJACOB_CRTL_BUS_ADDR_IER, Register & (~Mask));
}

void XJacob_InterruptClear(XJacob *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XJacob_WriteReg(InstancePtr->Crtl_bus_BaseAddress, XJACOB_CRTL_BUS_ADDR_ISR, Mask);
}

u32 XJacob_InterruptGetEnabled(XJacob *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XJacob_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XJACOB_CRTL_BUS_ADDR_IER);
}

u32 XJacob_InterruptGetStatus(XJacob *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XJacob_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XJACOB_CRTL_BUS_ADDR_ISR);
}

