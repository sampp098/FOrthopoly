// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2019.1 (64-bit)
// Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#include "xparameters.h"
#include "xjacob.h"

extern XJacob_Config XJacob_ConfigTable[];

XJacob_Config *XJacob_LookupConfig(u16 DeviceId) {
	XJacob_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XJACOB_NUM_INSTANCES; Index++) {
		if (XJacob_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XJacob_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XJacob_Initialize(XJacob *InstancePtr, u16 DeviceId) {
	XJacob_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XJacob_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XJacob_CfgInitialize(InstancePtr, ConfigPtr);
}

#endif

