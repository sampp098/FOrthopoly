// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2019.1 (64-bit)
// Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
// ==============================================================
/***************************** Include Files *********************************/
#include "xcheb1.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XCheb1_CfgInitialize(XCheb1 *InstancePtr, XCheb1_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Crtl_bus_BaseAddress = ConfigPtr->Crtl_bus_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XCheb1_Start(XCheb1 *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCheb1_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XCHEB1_CRTL_BUS_ADDR_AP_CTRL) & 0x80;
    XCheb1_WriteReg(InstancePtr->Crtl_bus_BaseAddress, XCHEB1_CRTL_BUS_ADDR_AP_CTRL, Data | 0x01);
}

u32 XCheb1_IsDone(XCheb1 *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCheb1_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XCHEB1_CRTL_BUS_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XCheb1_IsIdle(XCheb1 *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCheb1_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XCHEB1_CRTL_BUS_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XCheb1_IsReady(XCheb1 *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCheb1_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XCHEB1_CRTL_BUS_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XCheb1_EnableAutoRestart(XCheb1 *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XCheb1_WriteReg(InstancePtr->Crtl_bus_BaseAddress, XCHEB1_CRTL_BUS_ADDR_AP_CTRL, 0x80);
}

void XCheb1_DisableAutoRestart(XCheb1 *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XCheb1_WriteReg(InstancePtr->Crtl_bus_BaseAddress, XCHEB1_CRTL_BUS_ADDR_AP_CTRL, 0);
}

u32 XCheb1_Get_return(XCheb1 *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCheb1_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XCHEB1_CRTL_BUS_ADDR_AP_RETURN);
    return Data;
}
u64 XCheb1_Get_Val_r(XCheb1 *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCheb1_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XCHEB1_CRTL_BUS_ADDR_VAL_R_DATA);
    Data += (u64)XCheb1_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XCHEB1_CRTL_BUS_ADDR_VAL_R_DATA + 4) << 32;
    return Data;
}

u32 XCheb1_Get_Val_r_vld(XCheb1 *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCheb1_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XCHEB1_CRTL_BUS_ADDR_VAL_R_CTRL);
    return Data & 0x1;
}

u64 XCheb1_Get_Der(XCheb1 *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCheb1_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XCHEB1_CRTL_BUS_ADDR_DER_DATA);
    Data += (u64)XCheb1_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XCHEB1_CRTL_BUS_ADDR_DER_DATA + 4) << 32;
    return Data;
}

u32 XCheb1_Get_Der_vld(XCheb1 *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCheb1_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XCHEB1_CRTL_BUS_ADDR_DER_CTRL);
    return Data & 0x1;
}

u64 XCheb1_Get_DerK(XCheb1 *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCheb1_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XCHEB1_CRTL_BUS_ADDR_DERK_DATA);
    Data += (u64)XCheb1_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XCHEB1_CRTL_BUS_ADDR_DERK_DATA + 4) << 32;
    return Data;
}

u32 XCheb1_Get_DerK_vld(XCheb1 *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCheb1_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XCHEB1_CRTL_BUS_ADDR_DERK_CTRL);
    return Data & 0x1;
}

void XCheb1_Set_size(XCheb1 *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XCheb1_WriteReg(InstancePtr->Crtl_bus_BaseAddress, XCHEB1_CRTL_BUS_ADDR_SIZE_DATA, Data);
}

u32 XCheb1_Get_size(XCheb1 *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCheb1_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XCHEB1_CRTL_BUS_ADDR_SIZE_DATA);
    return Data;
}

void XCheb1_Set_k(XCheb1 *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XCheb1_WriteReg(InstancePtr->Crtl_bus_BaseAddress, XCHEB1_CRTL_BUS_ADDR_K_DATA, Data);
}

u32 XCheb1_Get_k(XCheb1 *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCheb1_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XCHEB1_CRTL_BUS_ADDR_K_DATA);
    return Data;
}

void XCheb1_Set_x(XCheb1 *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XCheb1_WriteReg(InstancePtr->Crtl_bus_BaseAddress, XCHEB1_CRTL_BUS_ADDR_X_DATA, (u32)(Data));
    XCheb1_WriteReg(InstancePtr->Crtl_bus_BaseAddress, XCHEB1_CRTL_BUS_ADDR_X_DATA + 4, (u32)(Data >> 32));
}

u64 XCheb1_Get_x(XCheb1 *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCheb1_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XCHEB1_CRTL_BUS_ADDR_X_DATA);
    Data += (u64)XCheb1_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XCHEB1_CRTL_BUS_ADDR_X_DATA + 4) << 32;
    return Data;
}

void XCheb1_InterruptGlobalEnable(XCheb1 *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XCheb1_WriteReg(InstancePtr->Crtl_bus_BaseAddress, XCHEB1_CRTL_BUS_ADDR_GIE, 1);
}

void XCheb1_InterruptGlobalDisable(XCheb1 *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XCheb1_WriteReg(InstancePtr->Crtl_bus_BaseAddress, XCHEB1_CRTL_BUS_ADDR_GIE, 0);
}

void XCheb1_InterruptEnable(XCheb1 *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XCheb1_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XCHEB1_CRTL_BUS_ADDR_IER);
    XCheb1_WriteReg(InstancePtr->Crtl_bus_BaseAddress, XCHEB1_CRTL_BUS_ADDR_IER, Register | Mask);
}

void XCheb1_InterruptDisable(XCheb1 *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XCheb1_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XCHEB1_CRTL_BUS_ADDR_IER);
    XCheb1_WriteReg(InstancePtr->Crtl_bus_BaseAddress, XCHEB1_CRTL_BUS_ADDR_IER, Register & (~Mask));
}

void XCheb1_InterruptClear(XCheb1 *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XCheb1_WriteReg(InstancePtr->Crtl_bus_BaseAddress, XCHEB1_CRTL_BUS_ADDR_ISR, Mask);
}

u32 XCheb1_InterruptGetEnabled(XCheb1 *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XCheb1_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XCHEB1_CRTL_BUS_ADDR_IER);
}

u32 XCheb1_InterruptGetStatus(XCheb1 *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XCheb1_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XCHEB1_CRTL_BUS_ADDR_ISR);
}

