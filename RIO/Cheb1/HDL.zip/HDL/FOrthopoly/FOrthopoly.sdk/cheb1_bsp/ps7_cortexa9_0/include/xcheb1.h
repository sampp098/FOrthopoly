// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2019.1 (64-bit)
// Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef XCHEB1_H
#define XCHEB1_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xcheb1_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
#else
typedef struct {
    u16 DeviceId;
    u32 Crtl_bus_BaseAddress;
} XCheb1_Config;
#endif

typedef struct {
    u32 Crtl_bus_BaseAddress;
    u32 IsReady;
} XCheb1;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XCheb1_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XCheb1_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XCheb1_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XCheb1_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
int XCheb1_Initialize(XCheb1 *InstancePtr, u16 DeviceId);
XCheb1_Config* XCheb1_LookupConfig(u16 DeviceId);
int XCheb1_CfgInitialize(XCheb1 *InstancePtr, XCheb1_Config *ConfigPtr);
#else
int XCheb1_Initialize(XCheb1 *InstancePtr, const char* InstanceName);
int XCheb1_Release(XCheb1 *InstancePtr);
#endif

void XCheb1_Start(XCheb1 *InstancePtr);
u32 XCheb1_IsDone(XCheb1 *InstancePtr);
u32 XCheb1_IsIdle(XCheb1 *InstancePtr);
u32 XCheb1_IsReady(XCheb1 *InstancePtr);
void XCheb1_EnableAutoRestart(XCheb1 *InstancePtr);
void XCheb1_DisableAutoRestart(XCheb1 *InstancePtr);
u32 XCheb1_Get_return(XCheb1 *InstancePtr);

u64 XCheb1_Get_Val_r(XCheb1 *InstancePtr);
u32 XCheb1_Get_Val_r_vld(XCheb1 *InstancePtr);
u64 XCheb1_Get_Der(XCheb1 *InstancePtr);
u32 XCheb1_Get_Der_vld(XCheb1 *InstancePtr);
u64 XCheb1_Get_DerK(XCheb1 *InstancePtr);
u32 XCheb1_Get_DerK_vld(XCheb1 *InstancePtr);
void XCheb1_Set_size(XCheb1 *InstancePtr, u32 Data);
u32 XCheb1_Get_size(XCheb1 *InstancePtr);
void XCheb1_Set_k(XCheb1 *InstancePtr, u32 Data);
u32 XCheb1_Get_k(XCheb1 *InstancePtr);
void XCheb1_Set_x(XCheb1 *InstancePtr, u64 Data);
u64 XCheb1_Get_x(XCheb1 *InstancePtr);

void XCheb1_InterruptGlobalEnable(XCheb1 *InstancePtr);
void XCheb1_InterruptGlobalDisable(XCheb1 *InstancePtr);
void XCheb1_InterruptEnable(XCheb1 *InstancePtr, u32 Mask);
void XCheb1_InterruptDisable(XCheb1 *InstancePtr, u32 Mask);
void XCheb1_InterruptClear(XCheb1 *InstancePtr, u32 Mask);
u32 XCheb1_InterruptGetEnabled(XCheb1 *InstancePtr);
u32 XCheb1_InterruptGetStatus(XCheb1 *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
