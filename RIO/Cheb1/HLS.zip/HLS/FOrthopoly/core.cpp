#include <hls_stream.h>
#include <ap_axi_sdata.h>
#include <hls_math.h>
#define max_P_size 200

//////////////////////////
double Cheb1Val(double *P, unsigned int n, double x)
{
    //assert ( 0 < n);
    //assert (fabs(x)<=1.0);
    double  xx,t,b1=0,b2=0;
    int i;
    xx=2*x;

    for(i=n; i>=1; i--)
    {
        t=xx*b1-b2+P[i];
        b2=b1;
        b1=t;
    }
    return x*b1-b2+P[0];
}
/*Cheb1Der evaluates  the first derivative of a series of Chebyshev polynomial of the first kind at the point x, which is in [-1, 1]. */
double Cheb1Der(double *P, unsigned int n, double x)
{
    //assert ( 0 < n);
    //assert (fabs(x)<=1.0);
    double  xx,t,b1=0,b2=0;
    int i;
    xx=2*x;

    for(i=n; i>=1; i--)
    {
        t=xx*b1-b2+(i)*P[i];
        b2=b1;
        b1=t;
    }
    return  b1;
}
/*Cheb1DerK evaluates  the k-th derivative of a series of Chebyshev polynomial of the first kind at the point x, which is in [-1, 1]. */
double Cheb1DerK(double *P, unsigned int n, double x, unsigned int k)
{
    //assert ( 0 < n);
    //assert (fabs(x)<=1.0);
    double  s=1.0,t,b1=0,b2=0;
    int i;
    double j;
    if(k==0){
    j=Cheb1Val(P,n,x);
    return j;
    }

    for(i=k-1;i>0;i--)
    {
       s=2*s*i;
    }

    for(i=n-k; i>=0; i--)
    {
        j=1.0*i;
        t=2*(j+k)/(j+1)*x*b1-(j+2*k)/(j+2)*b2+(j+k)*P[i+k];
        b2=b1;
        b1=t;
    }
    return  s*b1;
}
////////////////////////////

int cheb1(double &Val,double &Der,double &DerK,unsigned int size,unsigned int k,double p[max_P_size], double x){

#pragma HLS INTERFACE s_axilite port=k		bundle=CRTL_BUS
#pragma HLS INTERFACE s_axilite port=size bundle=CRTL_BUS
#pragma HLS INTERFACE s_axilite port=x bundle=CRTL_BUS

#pragma HLS INTERFACE s_axilite port=Val bundle=CRTL_BUS
#pragma HLS INTERFACE s_axilite port=Der bundle=CRTL_BUS
#pragma HLS INTERFACE s_axilite port=DerK bundle=CRTL_BUS
#pragma HLS INTERFACE s_axilite port=return bundle=CRTL_BUS

#pragma HLS INTERFACE bram port=p

	Val= Cheb1Val(p, size, x);
	Der= Cheb1Der(p, size, x);
	DerK= Cheb1DerK(p, size, x, k);
	return 0;
}
