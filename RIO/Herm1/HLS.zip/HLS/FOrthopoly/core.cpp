#include <hls_stream.h>
#include <ap_axi_sdata.h>
#include <hls_math.h>
#define max_P_size 200

//////////////////////////
double Herm1Val(double *P, unsigned int n, double x)
{
    //assert ( 0 < n);
    double  t,b1=0,b2=0;
    int i;

    for(i=n; i>=0; i--)
    {
        t=x*b1-(i+1)*b2+P[i];
        b2=b1;
        b1=t;
    }
    return b1;
}

/*Herm1Der evaluates the first derivative of a series of Hermite polynomial He at the point x. */
double Herm1Der(double *P, unsigned int n, double x)
{
    //assert ( 0 < n);
    double  t,b1=0,b2=0;
    int i;

    for(i=n-1; i>=0; i--)
    {
        t=x*b1-(i+1)*b2+(i+1)*P[i+1];
        b2=b1;
        b1=t;
    }
    return b1;
}

/*Herm1DerK evaluates  the k-th derivative of a series of Hermite polynomial He at the point x. */
double Herm1DerK(double *P, unsigned int n, double x, unsigned int k)
{
    //assert ( 0 < n);
    double  t,s,b1=0,b2=0;
    int i,j;

    for(i=n-k; i>=0; i--)
    {
        s=1.0;
        for(j=i+k;j>=i+1;j--)
        {
            s=s*j;
        }
        t=x*b1-(i+1)*b2+s*P[i+k];
        b2=b1;
        b1=t;
    }
    return b1;
}

////////////////////////////

int herm1(double &Val,double &Der,double &DerK,unsigned int size,unsigned int k,double p[max_P_size], double x){

#pragma HLS INTERFACE s_axilite port=k		bundle=CRTL_BUS
#pragma HLS INTERFACE s_axilite port=size bundle=CRTL_BUS
#pragma HLS INTERFACE s_axilite port=x bundle=CRTL_BUS

#pragma HLS INTERFACE s_axilite port=Val bundle=CRTL_BUS
#pragma HLS INTERFACE s_axilite port=Der bundle=CRTL_BUS
#pragma HLS INTERFACE s_axilite port=DerK bundle=CRTL_BUS
#pragma HLS INTERFACE s_axilite port=return bundle=CRTL_BUS

#pragma HLS INTERFACE bram port=p

	Val= Herm1Val(p, size, x);
	Der= Herm1Der(p, size, x);
	DerK= Herm1DerK(p, size, x, k);
	return 0;
}
