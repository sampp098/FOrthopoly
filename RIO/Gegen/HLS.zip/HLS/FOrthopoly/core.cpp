#include <hls_stream.h>
#include <ap_axi_sdata.h>
#include <hls_math.h>
#define max_P_size 200

//////////////////////////

void RecurCoefGegen (double n, double lambda,  double *A, double *C)
{
    int i;
    double j;
    for (i=1;i<=n+2;i++)
    {
        j=1.0*i;
        A[i-1]=2*(j+lambda-1)/j;
        C[i-1]=(j+2*lambda-2)/j;
        //printf("lambda:%f   C:%f   A:%f\n",lambda,C[i-1],A[i-1]);
    }
}

/*GegenVal evaluates a series of Gegenbauer polynomial at the point x, which is in [-1, 1] */
double GegenVal(double *P, unsigned int n, double x, double lambda)
{
    //assert ( 0 < n);
    //assert (fabs(x)<=1.0);
    //assert (lambda>-0.5);
    //assert (lambda!=0);
    double  t,b1=0,b2=0;
    int j;

    double A[max_P_size+2];
    double C[max_P_size+2];

    RecurCoefGegen(n,lambda,A,C);

    for(j=n; j>=0; j--)
    {
        t=*(A+j)*x*b1-*(C+j+1)*b2+P[j];
        b2=b1;
        b1=t;
    }
    //free(A);
    //free(C);
    return b1;
}

/*GegenDer evaluates  the first derivative of a series of Gegenbauer polynomial at the point x, which is in [-1, 1] */
double GegenDer(double *P, unsigned int n, double x, double lambda)
{
    //assert ( 0 < n);
    //assert (fabs(x)<=1.0);
    //assert (lambda>-0.5);
    //assert (lambda!=0);
    double  t,b1=0,b2=0;
    double A1, A2;
    int i;
    double j;
    double C=2*lambda;

    for(i=n-1; i>=0; i--)
    {
        j=1.0*i;
//-------------recurrence coefficients-----------------------//
        A1=2*(j+1+lambda)*x/(j+1);
        A2=-(j+2*lambda+2)/(j+2);
//--------------iteration------------------------------------//
        t=A1*b1+A2*b2+P[i+1];
        b2=b1;
        b1=t;
    }
    return  C*b1;
}

/*GegenDerK evaluates  the k-th derivative of a series of Gegenbauer polynomial at the point x, which is in [-1, 1] */
double GegenDerK(double *P, unsigned int n, double x, double lambda, unsigned int k)
{
    //assert ( 0 < n);
    //assert (fabs(x)<=1.0);
    //assert (lambda>-0.5);
    //assert (lambda!=0);
    double  s=1.0,t,b1=0,b2=0;
    double A1, A2;
    int i;
    double j;
    for(i=1;i<=k;i++)
    {
        s=2*s*(lambda+i-1);
     }

    for(i=n-k; i>=0; i--)
    {
        j=1.0*i;
//-------------recurrence coefficients-----------------------//
       	A1=2*(j+k+lambda)*x/(j+1);
       	A2=-(j+2*lambda+2*k)/(j+2);
//--------------iteration-----------------------------------//
        t=A1*b1+A2*b2+P[i+k];

        b2=b1;
        b1=t;
    }
    return  s*b1;
}



////////////////////////////

int gegen(double &Val,double &Der,double &DerK,unsigned int size,unsigned int k,double p[max_P_size], double x, double lambda){

#pragma HLS INTERFACE s_axilite port=k		bundle=CRTL_BUS
#pragma HLS INTERFACE s_axilite port=size bundle=CRTL_BUS
#pragma HLS INTERFACE s_axilite port=x bundle=CRTL_BUS
#pragma HLS INTERFACE s_axilite port=lambda bundle=CRTL_BUS

#pragma HLS INTERFACE s_axilite port=Val bundle=CRTL_BUS
#pragma HLS INTERFACE s_axilite port=Der bundle=CRTL_BUS
#pragma HLS INTERFACE s_axilite port=DerK bundle=CRTL_BUS
#pragma HLS INTERFACE s_axilite port=return bundle=CRTL_BUS

#pragma HLS INTERFACE bram port=p

	Val= GegenVal(p, size, x, lambda);
	Der= GegenDer(p, size, x, lambda);
	DerK= GegenDerK(p, size, x, k, lambda);
	return 0;
}
